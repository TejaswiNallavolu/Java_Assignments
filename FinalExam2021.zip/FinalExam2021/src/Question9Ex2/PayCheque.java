/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Question9Ex2;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
class PayCheque {

    public int depositCheque(int amt) throws ArithmeticException {
        return 50000 / amt;
    }

}
