/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Question6Ex2;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class UncheckedExceptions {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Answer to Question6Ex2: Tejaswi Reddy Nallavolu");
        int num = 1;
    int den = 0;
    int result = num / den;
        System.out.println(result);
    }
    
}
