/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accounts;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import payments.MobileService;


/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 04/07/2021
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */

public class ConnectionAccount {
    String customerName;
    String phoneNumber;
    String connectionType;
    String joiningDate;

    /**
     * this is a three argument constructor
     * @param customerName customerName
     * @param phoneNumber phoneNumber
     * @param connectionType connectionType
     */
    public ConnectionAccount(String customerName, String phoneNumber, 
            String connectionType) {
        this.customerName = customerName;
        this.phoneNumber = phoneNumber;
        this.connectionType = connectionType;
    }
    
    /**
     * this is a four argument constructor
     * @param customerName customerName
     * @param phoneNumber phoneNumber
     * @param connectionType connectionType
     * @param joiningDate joiningDate
     */
    public ConnectionAccount(String customerName, String phoneNumber, 
            String connectionType, String joiningDate) {
        this.customerName = customerName;
        this.phoneNumber = phoneNumber;
        this.connectionType = connectionType;
        this.joiningDate = joiningDate;
    }

    /**
     * this is a getter method for customer name
     * @return customer name
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * this is a getter method for phone number
     * @return phone number
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * this is a getter method for connection type
     * @return connection type
     */
    public String getConnectionType() {
        return connectionType;
    }

    /**
     * this is a getter method for joining date
     * @return joining date
     */
    public String getJoiningDate() {
        return joiningDate;
    }
    
    /**
     * this is a method to get number of years between joining date and present
     * date
     * @return between
     */
    public int numberOfyears(){
        int between= (int) ChronoUnit.YEARS.between( 
                LocalDate.parse(getJoiningDate(),DateTimeFormatter.
                        ofPattern("MM/dd/yyyy")) ,LocalDate.now());
        
        return  between;
    }
}

