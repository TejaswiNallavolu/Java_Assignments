/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rates;

/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 04/07/2021
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */
public enum Tarrif {
    /**
     * ENUM constant - local
     */
    LOCAL(19,20),

    /**
     * ENUM constant - roaming
     */
    ROAMING(29,30),

    /**
     * ENUM constant - international
     */
    INTERNATIONAL(69,70);
    private double postpaid;
    private double prepaid;
    
    
    /**
     * An all argument constructor that initializes all the instance variables of this class.
     * @param postpaid postpaid
     * @param prepaid prepaid
     */
    private Tarrif(double postpaid, double prepaid) {
        this.postpaid = postpaid;
        this.prepaid = prepaid;
    }

    /**
     * this is a getter method for postpaid
     * @return postpaid
     */
    public double getPostpaid() {
        return postpaid;
    }

    /**
     * this is a getter method for prepaid
     * @return prepaid
     */
    public double getPrepaid() {
        return prepaid;
    }
    
    
}



