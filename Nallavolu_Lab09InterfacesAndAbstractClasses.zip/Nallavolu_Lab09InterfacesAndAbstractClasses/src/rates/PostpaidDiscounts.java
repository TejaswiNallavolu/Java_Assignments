/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rates;

/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 04/07/2021
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */
public enum PostpaidDiscounts {

    /**
     * ENUM constant - year1
     */
    YEAR1(4),

    /**
     * ENUM constant - year2
     */
    YEAR2(8),

    /**
     * ENUM constant - year3
     */
    YEAR3(10),

    /**
     * ENUM constant - year4
     */
    YEAR4(15),

    /**
     * ENUM constant - year5
     */
    YEAR5(20);
    private double discount;

    private PostpaidDiscounts(double discount) {
        this.discount = discount;
    }

    /**
     * this is a getter method for discount
     * @return discount
     */
    public double getDiscount() {
        return discount;
    }
    
    
}
