/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payments;


/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 04/07/2021
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */

public interface Operations {
    /**
     * The method is used to check whether the customer can make a call.
     * @return booleanValue
     */ 
    public boolean canMakeCall();

    /**
     * The method is used to make a call.
     * @param call call
     * @return booleanValue
     */
    public boolean makeCall(Call call);

    /**
     * The method is used to update the amount of data available as the user 
     * uses mobile data or internet services.
     * @param dataUsed data used
     * @return booleanValue
     */
    public boolean useData(double dataUsed);
    
    
}


