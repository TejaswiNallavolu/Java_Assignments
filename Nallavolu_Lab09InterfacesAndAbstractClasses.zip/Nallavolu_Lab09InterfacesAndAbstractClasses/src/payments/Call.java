/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payments;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import rates.Tarrif;

/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 04/07/2021
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */
public class Call {
    Tarrif callType;
    String endTime;
    String phoneNumber;
    String startTime;

    /**
     * An all argument constructor that initializes all the instance 
     * variables of this class.
     * @param phoneNumber phone number
     * @param startTime start time
     * @param endTime end time
     * @param callType call type
     */
    public Call(String phoneNumber,String startTime,  String endTime,  Tarrif callType) {
        this.callType = callType;
        this.endTime = endTime;
        this.phoneNumber = phoneNumber;
        this.startTime = startTime;
    }

    /**
     * this is a getter method for call type
     * @return call type
     */
    public Tarrif getCallType() {
        return callType;
    }

    /**
     * this is a getter method for phone number
     * @return phone number
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * this is a method to get seconds
     * @return seconds
     */
    public double getSeconds(){
        double seconds=0.0;
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    LocalDateTime startdate = LocalDateTime.parse(startTime, dtf);
    LocalDateTime enddate = LocalDateTime.parse(endTime, dtf);
    seconds=Duration.between(startdate, enddate).getSeconds();        
    return seconds;
    }

     /**
     * this is a to string method to print output in specified format
     * @return to string
     */
    @Override
    public String toString() {
      return String.format("%-16s",phoneNumber)+String.format("%-23s",callType)
              +String.format("%-23s",startTime)+endTime+"\n";
    }
    
    
    
}

