/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payments;
import accounts.ConnectionAccount;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import rates.Tarrif;


/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 04/07/2021
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */
     public class TelecommDriver {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
         ArrayList<MobileService> connections=new ArrayList<MobileService>();
        Scanner sc=new Scanner(new File("usersCallLog.txt"));
        MobileService account = null;
        String ft=sc.next();
        while (sc.hasNext()) {
            String customername=ft+" "+sc.next();
            sc.nextLine();
            String connectiontype=sc.nextLine();
            String phnum=sc.nextLine(); 
            if(connectiontype.equalsIgnoreCase("postpaid")){
                String joiningdate=sc.nextLine();
                double dataAvailable=sc.nextDouble();
        ConnectionAccount connection=new ConnectionAccount(customername, phnum, 
                        connectiontype,joiningdate);
                account=new PostpaidService(connection, dataAvailable);
                
            }
            else{
                double balance=sc.nextDouble();
                double data=sc.nextDouble();
         ConnectionAccount connection=new ConnectionAccount(customername,phnum, 
                         connectiontype);
                 account=new PrepaidService(connection, balance, data);
            }

             ft=sc.next();
            
             do{
               String phonenumber=ft;
               String startdate1=sc.next();
               String startdate2=sc.next();
               String starttime=startdate1+" "+startdate2;
               String enddate1=sc.next();
               String enddate2=sc.next();
               String endtime=enddate1+" "+enddate2;
               String type=sc.next();
               Tarrif calltype;
               if(type.trim().equalsIgnoreCase("L")){
               calltype=Tarrif.LOCAL;
               }
               else if(type.trim().equalsIgnoreCase("R")){
                 calltype=Tarrif.ROAMING;  
               }
               else{
                  calltype=Tarrif.INTERNATIONAL; 
               }
               
               Call call=new Call(ft,starttime,endtime,calltype);
                
               if(connectiontype.equalsIgnoreCase("postpaid")){
                   account.makeCall(call);
               }
               else{
                  account.makeCall(call);
               }
               
               if(sc.hasNext()){
                   sc.nextLine();
                   ft=sc.next();
               }
               else{
                   break; 
               }
                  
             } while(ft.contains("+"));

              connections.add(account);
        }
            System.out.println("************************Postpaid customers "
                    + "invoice***************************");

            for(MobileService con:connections){
                if(con.getAccount().getConnectionType().equalsIgnoreCase
        ("postpaid")){
                    
                    System.out.println(con.toString());
                }
            }

            System.out.println("*************************Prepaid customers "
                    + "invoice***************************");

            for(MobileService con:connections){
                if(con.getAccount().getConnectionType().equalsIgnoreCase
        ("prepaid")){
                    System.out.println(con.toString());
                }
                
            }

            System.out.println("**********************Invoking useData() of "
                    + "customer*************************");

            for(MobileService service:connections){
                
                if(service.getAccount().getCustomerName().equalsIgnoreCase
        ("Aegon Targaryen")){
                    service.useData(156774.40);
                        System.out.println(service.toString());
                    
                }
                else if(service.getAccount().getCustomerName().equalsIgnoreCase
        ("Tyrion Lannister")){
                    service.useData(13516.80); 
                       System.out.println(service.toString());
                }
                else if(service.getAccount().getCustomerName().equalsIgnoreCase
        ("Eddard Stark")){
                    service.useData(104427.52); 
                       System.out.println(service.toString());
                }                  
            }

           System.out.println("*************************Best postpaid customer"
                   + "******************************");
                 PostpaidService post=(PostpaidService)(connections.get(0)); 
                 String custname=post.getAccount().getCustomerName();
                 double highestamount=post.finalBillAfterDiscount();
                 
                 for(MobileService service:connections){
                   if(service.getAccount().getConnectionType().equalsIgnoreCase
        ("postpaid")){
                         post=(PostpaidService)(service);
                         if(post.finalBillAfterDiscount()>highestamount){
                             highestamount=post.finalBillAfterDiscount();
                             custname=post.getAccount().getCustomerName();
                         }
                         
                     }
                 }
   System.out.println("Best Customer Details:\n	Customer Name:	"+
           custname+"\n	Bill amount	:$"+Math.round(highestamount*100)
                   /100.0);              
                 
                
            }

    }
