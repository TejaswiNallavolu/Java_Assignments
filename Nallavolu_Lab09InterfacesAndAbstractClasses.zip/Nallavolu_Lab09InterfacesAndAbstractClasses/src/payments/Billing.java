/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payments;

/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 04/07/2021
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */
public interface Billing {
    
    /**
     * This method is used to calculate the bill based on service.
     * @return cost of call
     */
    public double calcBill();

    /**
     * This method is used to calculate the discount of returning customer 
     * based on number of years the customer is active on the plan.
     * @return discount percentage
     */
    public double discountForReturningCustomer();
    
}


