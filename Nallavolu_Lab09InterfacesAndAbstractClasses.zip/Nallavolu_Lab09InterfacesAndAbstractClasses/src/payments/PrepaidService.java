/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payments;
import accounts.ConnectionAccount;
import rates.Tarrif;


/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 04/07/2021
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */
public class PrepaidService extends MobileService implements Billing,Operations{
    
    private Call call;

    /**
     * An all argument constructor that initializes all the instance variables of this class.
     * @param account account
     * @param balance balance
     * @param data data
     */
    public PrepaidService(ConnectionAccount account, double balance, 
            double data) {
        super(account, balance, data);
    }

    /**
     * This method will calculate the bill for the call duration.
     * @return call bill
     */
    @Override
    public double calcBill() {
        double callbill=0.0;
        switch (call.getCallType()) {
            case INTERNATIONAL:
          callbill=(call.getSeconds()/60)*Tarrif.INTERNATIONAL.getPrepaid()/100;
                break;
            case LOCAL:
          callbill=(call.getSeconds()/60)*Tarrif.LOCAL.getPrepaid()/100;
                break;
            default:
         callbill=(call.getSeconds()/60)*Tarrif.ROAMING.getPrepaid()/100;
             break;
        }
        return callbill;
    }

    /**
     * It is a method which returns true if balance is greater that 0
     * @return booleanValue
     */
    @Override
    public boolean canMakeCall() {
        boolean value=false;
        if(getBalance()>0){
            value=true;
        }
        return value;
    }

    /**
     * As prepaid customer does not have any discounts, return 0
     * @return double value
     */
    @Override
    public double discountForReturningCustomer(){
        return 0.0;
    }

    /**
     * This method  Calls object as input and verifies if they can make 
     * a call using canMakeCall.
     * @param call call
     * @return booleanValue
     */   
    @Override
    public boolean makeCall(Call call){
        boolean value=false;
        if(canMakeCall()){
            this.call=call;
           balance= getBalance()-calcBill();
            value=true;
        }
        return value;
        
    }
   

     /**
     *to string method to print output in specified format
     * @return to string
     */
    @Override
    public String toString() {
      return super.toString()+"\n---------------------------------------------"
                + "--------------------------------"+
        "\nLast Call Details:\n"+String.format("%-16s", "Phone number")
                +String.format("%-23s", "Call Type")+
        String.format("%-23s", "From")+"To\n"+call.toString()+"--------"
                + "------------------------------------------------------------"
                + "---------"+"\n    Available mobile data     :"+
                Math.round(Math.abs(getDataAvailable())*100)/100.0+
                "MB\n    Balance            :$"+Math.round(getBalance()*100)
                /100.0+"\n    Last Call Amount      :$"+
                Math.round(calcBill()*100.0)/100.0+
        "\n---------------------------------------------------------"
                + "--------------------\n";
    }
}

