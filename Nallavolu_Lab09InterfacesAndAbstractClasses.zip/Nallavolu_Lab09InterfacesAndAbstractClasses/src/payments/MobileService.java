/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payments;
import accounts.ConnectionAccount;

/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 04/07/2021
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */
public abstract class MobileService implements Operations{
    ConnectionAccount account;
    double balance;
    double dataAvailable;

    /**
     * An all argument constructor that initializes all the instance 
     * variables of this class.
     * @param account account
     * @param balance balance
     * @param dataAvailable dataAvailable
     */
    public MobileService(ConnectionAccount account, double balance, double dataAvailable) {
        this.account = account;
        this.balance = balance;
        this.dataAvailable = dataAvailable;
    }

    /**
     * This method overrides the abstract method declared in Operations 
     * interface.
     * @return booleanValue
     */
    public abstract boolean canMakeCall();

    /**
     * This getter method returns the account object of the customer for a 
     * mobile service.
     * @return account of type ConnectionAccount
     */
    public ConnectionAccount getAccount() {
        return account;
    }

    /**
     * This getter method returns the balance of the customer.
     * @return balance
     */
    public double getBalance() {
        return balance;
    }

    /**
     * this getter method returns the data available for a customer.
     * @return dataAvailable
     */
    public double getDataAvailable() {
        return dataAvailable;
    }
   
    /**
     * This method overrides the abstract method declared in Operations 
     * interface. This abstract method is used to make a call.
     * @param call call
     * @return booleanValue
     */
    public abstract boolean makeCall(Call call);

    /**
     * this is a to string method to print output in specified format
     * @return to string
     */
    @Override
    public String toString() {
       return "----------------------------------------------------------------"
                + "-------------\n"+String.format("%-18s", "Customer Name")+":"+
                account.getCustomerName()
                +"\n"+String.format("%-18s","Phone Number")+":"+"("+
                account.getPhoneNumber().substring(0,2)
                +")"+account.getPhoneNumber().substring(2,5)+"-"+
                account.getPhoneNumber().substring(5,8)+"-"+
                account.getPhoneNumber().substring(8)+"\n"+
                String.format("%-18s", "Connection Type")
                + ":"+account.getConnectionType();
    
    }
    
    /**
     * The method is used to update the amount of data available as the user 
     * uses mobile data or internet services. 
     * @param dataUsed data used
     * @return value
     */
    public boolean useData(double dataUsed){
        boolean value=false;
        dataAvailable=dataAvailable-(dataUsed/1024);
        if(dataAvailable>0){
            value=true;
        }
        return value;
    }
    
    
    
}
