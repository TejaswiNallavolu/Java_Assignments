/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payments;
import accounts.ConnectionAccount;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import rates.Tarrif;


/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 04/07/2021
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */
public class PostpaidService extends MobileService implements Operations, 
        Billing {

 private ArrayList<Call> calls;

    /**
     * An all argument constructor that initializes all the instance variables
     * of this class.
     * @param account account
     * @param dataAvailable dataAvailable
     */
    public PostpaidService(ConnectionAccount account, double dataAvailable) {
        super(account, 0.0,dataAvailable);
        calls=new ArrayList<Call>();
    }

    /**
     * This method calculates total cost for all calls and any additional data
     * used.
     * @return billAmount
     */
    @Override
    public double calcBill(){
         double billAmount=0.0;
         for(Call call:calls){
             switch (call.getCallType()) {
                 case INTERNATIONAL:
                     billAmount=billAmount+(Tarrif.INTERNATIONAL.getPostpaid()
                             /100)*(call.getSeconds()/60);
                     break;
                 case LOCAL:
                     billAmount=billAmount+(Tarrif.LOCAL.getPostpaid()/100)*
                             (call.getSeconds()/60);
                     break;
                 default:
                     billAmount=billAmount+(Tarrif.ROAMING.getPostpaid()/100)*
                             (call.getSeconds()/60);
                     break;
             }
        
         }
         if(getDataAvailable()<0){
             billAmount=billAmount+((Math.abs(getDataAvailable()))*0.05);
         }
         return billAmount;
    }

    /**
     * this method returns true if call is made
     * @return booleanValue
     */
    @Override
    public boolean canMakeCall(){
        return true;
    }

    /**
     * This method adds given call to calls and return whether call is added 
     * to calls or not.
     * @param call call
     * @return booleanValue
     */
    @Override
    public boolean makeCall(Call call){
       boolean b=false;
       if(calls.add(call)){
        b= true;
       }
       return b;
    }

    /**
     * The method is used to update the amount of data available as the user 
     * uses mobile data or internet services.
     * @param dataUsed dataUsed
     * @return booleanValue
     */
    @Override
    public boolean useData(double dataUsed){
        boolean b=false;
        dataAvailable=getDataAvailable()-(dataUsed/1024);
        b=true;
        return b;
    }

    /**
     * This method calculates the discount for returning customer based on 
     * number of years a postpaid customer is active on the mobile service.
     * @return discount
     */
    public double discountForReturningCustomer(){
        double discount=0.0;
        String startdate=getAccount().getJoiningDate();
        DateTimeFormatter d = DateTimeFormatter.ofPattern("M/d/yyyy");  
        LocalDate now = LocalDate.now();
        int currentyear=now.getYear();
        LocalDate startdate1=LocalDate.parse(startdate, d);
        int startyear=startdate1.getYear();
        int numyears=currentyear-startyear;
       
        if(numyears>=5){
            discount=rates.PostpaidDiscounts.YEAR5.getDiscount();
              
        }
        else if(numyears>=4){
            discount=rates.PostpaidDiscounts.YEAR4.getDiscount();
          
        }
        else if(numyears>=3){
            discount=rates.PostpaidDiscounts.YEAR3.getDiscount();
           
        }
        else if(numyears>=2){
            discount=rates.PostpaidDiscounts.YEAR2.getDiscount();
            
        }
        else if(numyears>=1){
             discount=rates.PostpaidDiscounts.YEAR1.getDiscount();
             
        }
        
       return discount;
       
    }

    /**
     * This method applies discount on calculated bill and will return the 
     * final bill after applying discount
     * @return final bill
     */
    public double finalBillAfterDiscount(){
        double discount=(discountForReturningCustomer()/100)*calcBill();
        return calcBill()-discount;
        
    }

     /**
     * this is a to string method to print output in specified format
     * @return to string
     */
   
   public String toString() {
        String calldetails="";
        double extradata=0.0;
        if(dataAvailable<0){
            extradata=Math.abs(dataAvailable);
        }
        DateTimeFormatter givenformat = DateTimeFormatter.ofPattern("M/d/yyyy");
        DateTimeFormatter outputformat = DateTimeFormatter.ofPattern
        ("dd-MMM-yyyy");
       
        LocalDate date = LocalDate.parse(getAccount().getJoiningDate(),
                givenformat);
        String newdate=outputformat.format(date);
      
        String s= "---------------------------------------------------"
                + "--------------------------\n"
        +String.format("%-16s","Phone number")+String.format("%-23s",
                 "Call Type")+String.format("%-23s","From")
                +String.format("%-23s","To")+"\n";
        for(Call call:calls){
          calldetails=calldetails+call.toString();
        }
        return super.toString()+"        Connection Date :"+newdate+"\n"
                +s+calldetails+
        "--------------------------------------------------------------"
                + "---------------\n"+"    Additional mobile data used    "
                + "    :"+String.format("%.2f", extradata)+
    "MB\n    Bill Amount                  :$"+String.format("%.2f"
                , Math.round(calcBill()*100.0)/100.0)+
        "\n    Returning Customer Discount"+"("+
                discountForReturningCustomer()+"%)    :$"+
        Math.round(((discountForReturningCustomer()/100.0)*calcBill())*
                        100)/100.0+
        "\n    Final Bill Amount              :$"+
                Math.round(finalBillAfterDiscount()*100.0)/100.0+
        "\n-----------------------------------------------------"
                + "------------------------\n";
    
    }   

}