/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Example;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class DemoDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Integer i=10;
         Integer j=11;
        System.out.println(i.compareTo(j));
        System.out.println(i.compareTo(i));
        System.out.println(j.compareTo(i));
    }
    
}
