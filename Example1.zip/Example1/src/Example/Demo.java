/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Example;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class Demo {
    private int i=10;
    private int j=11;
    
    public Demo(int i, int j){
        this.i=10;
        this.j=11;
       
    } 
}
