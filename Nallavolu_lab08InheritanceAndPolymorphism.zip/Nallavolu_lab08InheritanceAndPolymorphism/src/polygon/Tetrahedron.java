/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polygon;

/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 03/31/2021
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */
public class Tetrahedron extends EquilateralTriangle{
    /**
     * this is a one argument constructor
     * @param length length
     */
    public Tetrahedron(double length) {
        super("Tetrahedron",length);
    }

    /**
     * this is a getter method for height
     * @return height
     */
    public double getHeight(){
        return Math.sqrt(6)/3*getLength();
    }

    /**
     * this is a getter method for area
     * @return area
     */
    public double getArea(){
        return super.getArea()*enums.Solids.TETRAHEDRON.getNoFaces();
    }

    /**
     * this is a getter method for volume
     * @return volume
     */
    public double getVolume(){
        return Math.sqrt(2)/12*Math.pow(getLength(),3);
    }

    /**
     * this is a getter method for inSphere radius
     * @return InSphereRadius
     */
    public double getInSphereRadius(){
        return getLength()/Math.sqrt(24);
    }

    /**
     * this is a getter method for CircumSphereRadius
     * @return CircumSphereRadius
     */
    public double getCircumSphereRadius(){
        return Math.sqrt(6)/4*getLength();
    }
    
    /**
     * this is a to string method displays output in specified format
     * @return string of details of Tetrahedron
     */

    @Override
    public String toString() {
        return super.toString()+"\n	Insphere radius: "+String.format("%.2f",
                getInSphereRadius())+"cms"+"\n	Circumsphere radius: "+
                String.format("%.2f",getCircumSphereRadius())+"cms"+
                "\n	Volume: "+String.format("%.2f",getVolume())+"cm\u00b3";
    }
    

    
}
