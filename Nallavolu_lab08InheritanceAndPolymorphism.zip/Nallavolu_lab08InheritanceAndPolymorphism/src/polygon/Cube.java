/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polygon;

/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 03/31/2021
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */
public class Cube extends Square {
    /**
     * this is a one argument constructor
     * @param length length
     */
    public Cube(double length) {
        super("Cube",6,length);
    }

    /**
     * this is a getter method for area
     * @return area
     */
    @Override
    public double getArea(){
        return super.getArea()*enums.Solids.CUBE.getNoFaces();
    }

    /**
     * this is a getter method for volume
     * @return volume
     */
    public double getVolume(){
            return Math.pow(getLength(),3);
    }

    /**
     * this is a getter method for inSphere radius
     * @return inSphere radius
     */
    public double getInSphereRadius(){
        return getLength()/2;
    }

    /**
     * this is a getter method for circumSphere radius
     * @return circumSphere radius
     */
    public double getCircumSphereRadius(){
       return Math.sqrt(3)/2*getLength();
    }
    
    /**
     * this is a to string method displays output in specified format
     * @return string of details of cube
     */

    @Override
    public String toString() {
        String s = super.toString();
        return s+"\n	Insphere radius: "+String.format("%.2f",
                getInSphereRadius())+"cms"+"\n	Circumsphere radius: "+
                String.format("%.2f",getCircumSphereRadius())+"cms"+
                "\n	Volume: "+String.format("%.2f",getVolume())+"cm\u00b3";
    }
    
        
}

    

