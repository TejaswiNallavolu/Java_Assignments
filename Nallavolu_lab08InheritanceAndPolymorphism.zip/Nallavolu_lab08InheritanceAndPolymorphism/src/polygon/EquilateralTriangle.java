/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polygon;

/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 03/31/2021
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */
public class EquilateralTriangle extends RegularPolygon{
    /**
     * this is a one argument constructor
     * @param length length
     */
    public EquilateralTriangle(double length) {
        super("Equilateral Triangle", 3, length);
    }

    /**
     * this is a two argument constructor
     * @param name name
     * @param length length
     */
    public EquilateralTriangle(String name, double length) {
        super(name, 3, length);
    }

    /**
     * this is a getter method for height
     * @return height
     */
    public double getHeight(){
        return Math.sqrt(3)/2*getLength();
    }

    /**
     * this is a to string method displays output in specified format
     * @return string of details of Equilateral triangle
     */
    @Override
    public String toString() {
    return super.toString()+"\n	Height: "+String.format("%.2f",getHeight())+
                "cms";
    }
    
}

    

