/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polygon;
import enums.Solids;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;


/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 03/31/2021
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */
public class ShapesDriver {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
        
        // TODO code application logic here
        
        ArrayList<Polygon> polygonList=new ArrayList<>();
        Scanner scan=new Scanner(new File("shapes.txt"));
        while(scan.hasNext()){
            String name=scan.next();
            String name1=name.toUpperCase().substring(0,1)+name.substring(1);
            if(name.equalsIgnoreCase("cube"))
            {
                double length=scan.nextDouble();
                Cube cube=new Cube(length);
                polygonList.add(cube);
            }
            else if(name.equalsIgnoreCase("triangle")||name.equalsIgnoreCase
        ("equilateral triangle"))
            {
                double tlength=scan.nextDouble();
                EquilateralTriangle triangle=new EquilateralTriangle(tlength);
                polygonList.add(triangle);
            }
            else if(name.equalsIgnoreCase("tetrahedron"))
            {
                double tetralength=scan.nextDouble();
                Tetrahedron tetrahedron=new Tetrahedron(tetralength);
                polygonList.add(tetrahedron);
            }
            else if(name.equalsIgnoreCase("square"))
            {
                double slength=scan.nextDouble();
                Square square=new Square(slength);
                polygonList.add(square);
            }
            else if(name.equalsIgnoreCase("pentagon")||name.equalsIgnoreCase
        ("hexagon")||name.equalsIgnoreCase("heptagon")||name.equalsIgnoreCase
        ("nonagon")||name.equalsIgnoreCase("decagon"))
            {
               int side=scan.nextInt();
               double length=scan.nextDouble();
               RegularPolygon rpolygon=new RegularPolygon(name1, side, length);
               polygonList.add(rpolygon);
            }
            
        }   
        System.out.println("*****************************************");
        for(Polygon p:polygonList)
        {
            String o = p.toString();
            System.out.println(o);
            System.out.println("*****************************************");
        }
         double max=0.0;
         String name="";
          double min = polygonList.get(0).getArea();
        String name1="";
        for(Polygon p:polygonList)
        {
            if(p.getArea()>max)
            {
                max=p.getArea();   
                name=p.getName();
            } 
            if(min>p.getArea())
            {
                min=p.getArea();
                name1=p.getName();
            }
            
        }
     System.out.println("The polygon with largest area is "+name+" with area"
                + " of "+String.format("%.2f",max)+"cm\u00b2");
     System.out.println("The polygon with smallest area is "+name1+" with area"
                + " of "+String.format("%.2f",min)+"cm\u00b2");
        
       
         double pmax=0.0;
         String name2="";
          double pmin = polygonList.get(0).getPerimeter();
        String name3="";
        for(Polygon p:polygonList)
        {
            if(p.getPerimeter()>pmax)
            {
                pmax=p.getPerimeter();   
                name2=p.getName();
            } 
            if(pmin>p.getPerimeter())
            {
                pmin=p.getPerimeter();
                name3=p.getName();
            }
            
        }
        System.out.println("The polygon with largest perimeter is "+name2+" "
                + "with perimeter"
                + " of "+String.format("%.2f",pmax)+"cms");
        System.out.println("The polygon with smallest perimeter is "+name3+" "
                + "with perimeter"
               + " of "+String.format("%.2f",pmin)+"cms");
        System.out.println("*****************************************");
        System.out.println("Surface area to Volume ratio of given solids are:");
        for(Polygon p:polygonList)
        {
            if(p.getName().equalsIgnoreCase(Solids.CUBE.toString()))
            {
                Cube c=(Cube)p;
                System.out.println(p.getName()+":\n	Surface area: "+
               String.format("%.2f",p.getArea())+"cm\u00b2"+"\n	Volume: "+
                 String.format("%.2f",c.getVolume())+"cm\u00b3");
            }
            else if(p.getName().equalsIgnoreCase(Solids.TETRAHEDRON.toString()))
            {
                Tetrahedron t = (Tetrahedron) p;
                System.out.println(p.getName() + ":\n" + "	Surface area: "
                        + String.format("%.2f", p.getArea()) + "cm\u00b2" + "\n	Volume: "
                        + String.format("%.2f", t.getVolume()) + "cm\u00b3");
            }
        }
       System.out.println("******************************************");
       System.out.println("Late Binding Polymorphism is used while printing the"
             + " maximum and minimum area, perimeter and toString() methods.");
        System.out.println("*****************************************");
        System.out.println("Polymorphic substitution is used while calculating"
                + " volume of solids by using type casting.");
         System.out.println("*****************************************");
               
       
    }
    
}

    