/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polygon;

/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 03/31/2021
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */
public class RegularPolygon extends Polygon{
        private double length;
/**
     * this is a three argument constructor
     * @param name name
     * @param noSides no of sides
     * @param length length
     */
    public RegularPolygon(String name, int noSides, double length) {
        super(name, noSides);
        this.length=length;
    }

    /**
     * this is a getter method for length
     * @return length
     */
    public double getLength() {
        return length;
    }

    /** This method calculates area of polygon
     * 
     * @return area
     */
    @Override
    public double getArea(){
        int a =super.getNoSides();
        double s = Math.pow(length, 2);
        double aea = 0.25 * a* s * 1/(Math.tan(Math.PI/a));
        return aea;
    }
    
    /** This method calculates the perimeter of polygon
     * 
     * @return perimeter 
     */
    @Override
    public double getPerimeter(){
      double  perimeter = this.length * this.getNoSides();
        return perimeter;
    }
    
    double internalAngle = 0;
    /** This method returns the internal angle of the polygon
     * 
     * @return internalAngle
     */
    @Override
    public double getInternalAngle(){
        internalAngle = 180/this.getNoSides() *(this.getNoSides() -2);
        return internalAngle;
    }
    
    double radius = 0.0;
    /** This method calculates circle radius of polygon
     * 
     * @return radius
     */
    public double getInCircleRadius(){
        radius = (this.length/2) * (1/Math.tan(Math.PI/this.getNoSides()));
        return radius;
    }
    
    double circumRadius = 0.0;
    /** This method calculates circumcircle radius of polygon
     * 
     * @return circumRadius
     */
    public double getCircumCircleRadius(){
       // radius = (this.length/2) * (1/Math.sin(Math.PI/this.getNoSides()));
       double d = length/2;
       double cs = Math.pow(Math.sin(Math.PI/super.getNoSides()), -1);
       cs = d * cs;
       return cs;
    }
@Override
    public String toString() {
        double cr = getCircumCircleRadius();
        double a = getArea();
        return super.toString()+ "\n" +
               "	Length of side: " + length+"cms" + "\n" +
               "	Internal angle: " + String.format("%1.2f", getInternalAngle())+"\u00b0"+ "\n" +
               "	Circumcircle radius: " + String.format("%1.2f", cr)+"cms" + "\n"+
               "	Incircle radius: " + String.format("%1.2f", getInCircleRadius()) +"cms" +"\n"+
               "	Area: " + String.format("%1.2f", getArea())+"cm\u00b2" +"\n" +
               "	Perimeter: " + String.format("%1.2f", getPerimeter())+"cms";
    }
    

    
}
