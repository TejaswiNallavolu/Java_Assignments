/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polygon;

/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 03/31/2021
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */
public class Square extends RegularPolygon {
    
   
    /** This is single argument constructor
     * 
     * @param length 
     */
    public Square( double length) {
        super("Square", 4, length);
    }
    
/**
     * this is a three argument constructor
     * @param name name
     * @param noSides no of sideS
     * @param length length
     */
    public Square(String name, int noSides, double length) {
        super(name, 4, length);
        
    }

  

    /**
     * this is a getter method for area
     * @return area
     */
    @Override
    public double getArea(){ 
       return 0.25*getNoSides()*Math.pow(getLength(),2)*(1/Math.tan(Math.PI/getNoSides()));
    }

    /**
     * this is a getter method for perimeter
     * @return perimeter
     */
    @Override
    public double getPerimeter(){
        return getNoSides()*getLength();
    }

    /**6
     * this is a getter method for internal angle
     * @return internal angle
     */
    @Override
    public double getInternalAngle(){
        return 180/getNoSides()*(getNoSides()-2);
    }

    /**
     * this is a getter method for inCircle radius
     * @return inCircle radius
     */
    public double getInCircleRadius(){
        return getLength()/2*(1/Math.tan(Math.PI/getNoSides()));
    }

    /**
     * this is a getter method for circumCircle radius
     * @return circumCircle radius
     */
    public double getCircumCircleRadius(){
        return getLength()/2*(1/Math.sin(Math.PI/getNoSides()));
    }

    
    
}

    

