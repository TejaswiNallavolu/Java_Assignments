/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enums;

/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 03/31/2021
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */
public enum Solids {
    /**
     * ENUM constant - TETRAHEDRON
     */
    TETRAHEDRON(4),

    /**
     * ENUM constant - CUBE
     */
    CUBE(6),

    /**
     * ENUM constant - BOX
     */
    BOX(6);
    private final int noFaces;
    private Solids(int noFaces){
       this.noFaces=noFaces;        
    }

    /**
     * this is getter method for tetrahedron
     * @return tetrahedron
     */
    public static Solids getTETRAHEDRON() {
        return TETRAHEDRON;
    }

    /**
     * this is getter for cube
     * @return cube
     */
    public static Solids getCUBE() {
        return CUBE;
    }

    /**
     * this is getter method for box
     * @return box
     */
    public static Solids getBOX() {
        return BOX;
    }

    /**
     * this is getter method for NoFaces
     * @return noFaces
     */
    public int getNoFaces() {
        return noFaces;
    }
   

}

