/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Java;
import JAVA.LLExercise;
import java.util.LinkedList;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class Main 
{

    /**
     * @param args the command line arguments
     */
    
    private static LinkedList<Integer>myList;
    private static void printList()
    public static void main(String[] args) {
       
        myList = new LinkedList<>();
        myList.addFirst(3);
         myList.addFirst(5);
          myList.addFirst(7);
        //testing linkedlist exercises
        LLExercise objLLExercise = new LLExercise ();
        objLLExercise.testLL();
        
        
        // Test List
        /*
        TestList list = new TestList();
        list.testArrayList();
        list.testLinkedList();
        */
        
        // Test Set
        /*
        TestSet set = new TestSet();
        set.testHashSet();
        set.testTreeSet();
        */
        
        //Test Queue
        /*
        TestQueue queue = new TestQueue();
        queue.testPriorityQueue();
        queue.testArrayDeque();
        */
        
        // Test Map
       // TestMap map = new TestMap();
       // map.testHashMap();
       // map.testTreeMap();
    }
    
}
