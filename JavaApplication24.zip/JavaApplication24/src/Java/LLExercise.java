/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Java;
import java.util.Iterator;
import java.util.LinkedList;
/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class LLExercise {
    
    //Linked list exercise
    
    //display linked list
    public void display(LinkedList list){
        
        //create an instance 
        Iterator<Integer>objIterator = list.iterator();
        System.out.print("list ");
        while(objIterator.hasNext()){
            System.out.print(" ->"+objIterator.hasNext());
        }
        System.out.println(" ->null");
    }
    public void testLL(){
        LinkedList<Integer>objLinkedList =new LinkedList<>();
        
        display(objLinkedList);
        objLinkedList.addFirst(3);
       
         display(objLinkedList);
    }
            
}
