/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;
import java.util.ArrayList;
import java.util.Formatter;


/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 03/24/21
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */
public class OrdersSummary {

    private  ArrayList<Order> orders;

    /**
     *This is an no-argument constructor that initializes orders
     */
    public OrdersSummary() {
        orders = new ArrayList<>();
    }

    /**
     *This method gives list of orders
     * @return list of orders
     */
    public ArrayList<Order> getOrders() {
        return orders;
    }

    /**
     *This method adds the order to orders arrayList
     * @param order placed
     */
    public void addAOrder(Order order){
        orders.add(order);    
    }

    /**
     *This method calculates the total cost
     * @param orderDate date when the order has been placed
     * @return total cost of all Orders
     */
    public double calcTotalCostOfAllOrders(String orderDate){
       double cost =0.0;
       for (Order ord: orders){
       cost=ord.getTotalCost(orderDate);  
   }
       return cost;
   }

    /**
     *This method calculates totalBill with Tax
     * @param orderDate date when the order has been placed
     * @return totalBill with Tax
     */
    public double calcTotalBillWithTax(String orderDate){
       
       double taxRate =0.0;
       double totalCost=0.0;
       for (Order ord: orders){
       taxRate=(ord.getTotalCost(orderDate)-ord.calcDiscount(orderDate))*
               8.6/100; 
       totalCost = ord.getTotalCost(orderDate)-ord.calcDiscount(orderDate)
               +taxRate;
   }
       return totalCost;   
}

    /**
     *This method prints the receipt 
     * @param orderDate date when the order has been placed
     * @return receipt of all the orders placed
     */
    public String printReceipt(String orderDate){
      String receipt="";

      
      for (Order ord: orders){
       String date ="**************  "+orderDate+", "+
              Days.getOrderDayOfWeek(orderDate)+"  ***************";
       double taxRate=(ord.getTotalCost(orderDate)-ord.calcDiscount(orderDate))*
               8.6/100;   
       receipt= date+ord.toString()+"\n---------------------------------------"
               + "--"
               + "------------"+"\n		"+
               "Order Total :		$"+String.format("%.02f",(double)Math.
                       round(ord.getTotalCost(orderDate)*100)/100)+
               "\n		"+
               "Discount@50 :		$"+String. 
                       format("%.02f",ord.calcDiscount(orderDate))+ 
               "\n		"+
               "Tax@8.6 :		$"+String. 
                       format("%.02f",(double)Math.round(taxRate*100)/100)+
               "\n		"+
               "Total Amount with tax : $"
               +String.format("%.02f",(double)Math.round
        (calcTotalBillWithTax(orderDate)*100)/100)+
               "\n-----------------------------------------"
               + "------------";
                 
   }
      
  return receipt;
  }
}
