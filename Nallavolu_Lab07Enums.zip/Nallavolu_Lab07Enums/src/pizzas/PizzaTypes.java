/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 03/24/21
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */


public enum PizzaTypes {
    /**
     *This has  values of the pizza types and items prices for 
     small, medium, large 
     */
    HANDTOSSED_PIZZA(10.50,13.50,16.50),

    /**
     *This has values of the pizza types and items prices for
     small, medium, large 
     */
    PAN_PIZZA(9.50,12.50,15.50);
    
    private final double smallPizzaPrice;
    private final double mediumPizzaPrice;
    private final double largePizzaPrice;

    private  PizzaTypes(double smallPizzaPrice, double mediumPizzaPrice, 
            double largePizzaPrice) {
        this.smallPizzaPrice = smallPizzaPrice;
        this.mediumPizzaPrice = mediumPizzaPrice;
        this.largePizzaPrice = largePizzaPrice;
    }

    /**
     *This method gets pizza types
                    small, medium, large of a pizza type
     * @return prices for handtossed pizza
     */
    public static PizzaTypes getHANDTOSSED_PIZZA() {
        return HANDTOSSED_PIZZA;
    }

    /**
     *This method gets pan pizza 
                    small, medium, large of a pizza type
     * @return prices for 
                   small, medium, large of a pizza type
     */
    public static PizzaTypes getPAN_PIZZA() {
        return PAN_PIZZA;
    }

    /**
     *This method gets small pizza price
     * @return small pizza price
     */
    public double getSmallPizzaPrice() {
        return smallPizzaPrice;
    }

    /**
     *This method gets medium size pizza type
     * @return medium pizza price
     */
    public double getMediumPizzaPrice() {
        return mediumPizzaPrice;
    }

    /**
     *This method gets Large size of a pizza price
     * @return price for Large size of a pizza 
     */
    public double getLargePizzaPrice() {
        return largePizzaPrice;
    }
     
    
    
}


