/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 *//**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 03/24/21
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */

public class Order {

    private PizzaTypes pizzasName;
    private String pizzasSize;
    private int quantity;
    private Sauces sauce;
    private Sides side;
    private String sideSize;
    private Drinks drink;
    private Sides.Cheese cheese;
    private Desserts dessert;
    private Double cost;

    /**
     *This constructor is used to initialize the values to the variables
     * @param pizzasName Name of the pizzas ordered
     * @param pizzasSize Size of the pizzas (size here refers to small,
                    medium or large)
     * @param quantity Number of pizzas ordered by the customer.
                   A customer must order at least one type of pizza.
     * @param sauce Name of a sauce ordered seasoned to pizzas
     * @param side Name of a side ordered
     * @param sideSize Size of the side ordered
                     (size here refers to small, family and party)
     * @param drink Name of drinks ordered
     * @param cheese Name of cheese ordered with a side
     * @param dessert Name of dessert ordered
     */
    public Order(PizzaTypes pizzasName, String pizzasSize, int quantity, Sauces
            sauce, Sides side, String sideSize, Drinks drink, Sides.Cheese
                    cheese, Desserts dessert) {
        this.pizzasName = pizzasName;
        this.pizzasSize = pizzasSize;
        this.quantity = quantity;
        this.sauce = sauce;
        this.side = side;
        this.sideSize = sideSize;
        this.drink = drink;
        this.cheese = cheese;
        this.dessert = dessert;
        this.cost = cost;
    }

    /**
     *This method gets Name of the pizzas ordered
     * @return Name of the pizzas 
     */
    public PizzaTypes getPizzasName() {
        return pizzasName;
    }

    /**
     *This method gets Size of the pizzas
      * @return Size of the pizzas (size here refers to small, medium or large)
     */
    public String getPizzasSize() {
        return pizzasSize;
    }

    /**
     *This method gets Number of pizzas ordered by the customer.
                      A customer must order at least one type of pizza.
     * @return Number of pizzas ordered by the customer.
                A customer must order at least one type of pizza.
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     *This method gets Name of a sauce o
     * @return sauce 
     */
    public Sauces getSauce() {
        return sauce;
    }

    /**
     *This method gets Name of a side ordered
     * @return side
     */
    public Sides getSide() {
        return side;
    }

    /**
     *This method gets Size of the side 
                         (size here refers to small, family and party)
     * @return Size of the side 
                       (size here refers to small, family and party)
     */
    public String getSideSize() {
        return sideSize;
    }

    /**
     *This method gets Name of drinks ordered
     * @return Name of drinks ordered
     */
    public Drinks getDrink() {
        return drink;
    }

    /**
     *This method gets Name of cheese ordered
     * @return Name of cheese ordered with a side
     */
    public Sides.Cheese getCheese() {
        return cheese;
    }

    /**
     *This method gets Name of dessert 
     * @return Name of dessert ordered
     */
    public Desserts getDessert() {
        return dessert;
    }

    /**
     *This method fetches Total cost 
     * @return Total cost of the order
     */
    public Double getCost() {
        return cost;
    }

    /**
     *This method sets Total cost 
     *@param cost of the order
     */
    public void setCost(Double cost) {
        this.cost = cost;
    }


    private double calcDessertCost(){
       Double price=0.0;
   
       price= dessert.getDessertPrice();
        //}
    return price;
}
    private double calcSauceCost(){
      Double price=0.0;
   
            price= sauce.getPriceOfSauce();
     
    return price;
}
     private double calcCheeseCost(){
       Double price=0.0;
       
            price= cheese.getCheesePrice();
    
    return price;
}
     private double calcDrinkCost(){

   Double price=0.0;
        
            price= drink.getDrinkPrice();
      
    return price;
}
  private double calcSideCost(){

   Double price=0.0;
            if (sideSize.equalsIgnoreCase("SMALL")){
                price=side.getSmallSidesPrice();
            }
           if (sideSize.equalsIgnoreCase("FAMILY")){
                price=side.getFamilySidesPrice();
            }
           if (sideSize.equalsIgnoreCase("PARTY")){
                price=side.getPartySidesPrice();
            }
    return price;
}

    /**
     * This method will calculate the cost
     * @return cost of the pizzas
     */
    public double calcPizzasCost(){

   Double price=0.0;
            if (pizzasSize.equalsIgnoreCase("SMALL")){
               price=pizzasName.getSmallPizzaPrice();
              
            }
            if (pizzasSize.equalsIgnoreCase("MEDIUM")){
                price=pizzasName.getMediumPizzaPrice();
                
            }
            if (pizzasSize.equalsIgnoreCase("LARGE")){
                price=pizzasName.getLargePizzaPrice();
                 
            }
    return price;
}

    /**
     *This method calculates the cost with discount
     * @param orderDate orderdate
     * @return the cost with discount
     */
    public double calcDiscount(String orderDate)  {
     double price=0.0;
     if(Days.isDiscountDay(orderDate)==true){
         PizzaTypes  value =PizzaTypes.valueOf("HANDTOSSED_PIZZA");
         if (pizzasName.equals(value)){
            if (pizzasSize.equalsIgnoreCase("SMALL")){
             price =(50/100.0)*(pizzasName.getSmallPizzaPrice()*quantity);
         }
            else if (pizzasSize.equalsIgnoreCase("MEDIUM")){
             price =(50/100.0)*(pizzasName.getMediumPizzaPrice()*quantity);  
         }
            else if (pizzasSize.equalsIgnoreCase("LARGE")){
             price =(50/100.0)*(pizzasName.getLargePizzaPrice()*quantity);
         }
    
 }
 
}
     return price;
    }
    

    /**
     *This method gets total cost without discount
     * @param orderDate without discount
     * @return total cost of the order without discount
     */
    public double getTotalCost(String orderDate){
     //double pPrice=calcPizzasCost()*quantity;
     cost = calcSauceCost()+calcDessertCost()+calcCheeseCost()+calcDrinkCost()+
             calcSideCost()+(calcPizzasCost()*quantity);
     return cost;
 }

    /**
     *This method is a toString
     * @return string 
     */
    @Override
    public String toString() {
        return ("\nPIZZA TYPE: "+pizzasName.name().replace("_"," ")+
                "\nPIZZA SIZE: "+
                pizzasSize+
                "\nQUANTITY: "+quantity+"\nSAUCE: "+sauce.name().
                        replace("_"," ")+"\nSIDES: "+side.name().
                        replace("_"," ")+" "
                +"("+sideSize+")"+"\nCHEESE: "+cheese.name().replace("_"," ")
                +"\nDRINKS: "+drink.name().replace("_"," ")+
                "\nDESSERTS: "+dessert.name().replace("_"," ")+"\nCOST: "+
                String.format("%.02f",(double)Math.
                       round(getCost()*100)/100));
    }

}
