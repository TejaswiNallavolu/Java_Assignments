/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 03/24/21
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */
public enum Sides {
    /**
     *This contains the Sides cost (in dollars) for small, 
             family and party size prices 
     */
    GARLIC_CHEESEBREAD(6.99,24.99,39.99),

    /**
     *This contains the Sides cost (in dollars) for small, 
             family and party size prices
     */
    CHEFSALAD(3.99,15.99,29.99),

    /**
     *This contains the Sides cost (in dollars) for small, 
             family and party size prices
     */
    RANCH_STIX(1.99,7.99,12.99),

    /**
     *This contains the Sides cost (in dollars) for small, 
             family and party size prices
     */
    RANCH_POTATO_WEDGES(2.99,10.99,20.99),

    /**
     *This contains the Sides cost (in dollars) for small, 
             family and party size prices
     */
    MASHED_POTATOES(5.99,16.99,32.99),

    /**
     *This contains the Sides cost (in dollars) for small, 
             family and party size prices
     */
    RANCH_CHIPS(3.99,17.99,32.99),

    /**
     *This contains the Sides cost (in dollars) for small, 
             family and party size prices
     */
    PARMESAN_BROCCOLI(2.99,7.99,16.99),

    /**
     *This contains the Sides cost (in dollars) for small, 
             family and party size prices
     */
    ONION_RINGS(4.99,7.49,29.49),

    /**
     *This contains the Sides cost (in dollars) for small, 
             family and party size prices
     */
    NO_SIDES(0.00,0.00,0.00);
    private double smallSidesPrice;
    private double familySidesPrice;
    private double partySidesPrice;

    private Sides(double smallSidesPrice, double familySidesPrice, 
            double partySidesPrice) {
        this.smallSidesPrice = smallSidesPrice;
        this.familySidesPrice = familySidesPrice;
        this.partySidesPrice = partySidesPrice;
    }

    /**
     *This method gets Price 
     * @return Price for the small sides price
     */
    public double getSmallSidesPrice() {
        return smallSidesPrice;
    }

    /**
     *This method gets Price for the family size sides in dollars
     * @return family size sides
     */
    public double getFamilySidesPrice() {
        return familySidesPrice;
    }

    /**
     *This method gets Price for the party size sides in dollars
     * @return party size sides 
     */
    public double getPartySidesPrice() {
        return partySidesPrice;
    }

    /**
     *This contains the different types of cheese cost (in dollars) for a cheese 
     */
    public enum Cheese {

        /**
         *This contains the cheese cost (in dollars) for a cheese 
         */
        AMERICAN_CHEESE(0.55), CHEDDAR_CHEESE(0.60),  CHEDDAR_JACK_CHEESE(0.70), PEPPER_JACK_CHEESE(0.59), QUESO_CHEESE(0.65), SWISS_CHEESE(0.60), BLUE_CHEESE(0.60), RANCH(0.60),

        NO_CHEESE(0.0);
        private double cheesePrice;

        private Cheese (double cheesePrice) {
            this.cheesePrice = cheesePrice;
        }

        /**
         *This method fetches the cheese cost (in dollars) for a cheese
         * @return the cheese cost
         */
        public double getCheesePrice() {
            return cheesePrice;
        }

         }
    
}


