/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 03/24/21
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code 
 * with anyone under my circumstances.
 */

public class Days {

    private Days() {
    }

    /**
     *This method fetches day of the week based on the order date
     * @param orderDate date when the order has been placed
     * @return day of the week based on the order date
     */
    public static DayOfWeek getOrderDayOfWeek(String orderDate){
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
    LocalDate date = LocalDate.parse(orderDate, formatter);
      DayOfWeek dayOfWeek = date.getDayOfWeek();
   return dayOfWeek;
  }

    /**
     *This method fetches if the order date is SATURDAY or SUNDAY and 
             returns true, otherwise false
     * @param orderDate date when the order has been placed.
     * @return true or false
     */
    public static boolean isDiscountDay(String orderDate){
     if(getOrderDayOfWeek(orderDate).equals(DayOfWeek.SUNDAY)||
             getOrderDayOfWeek(orderDate).equals(DayOfWeek.SATURDAY)){ 
         return true;
     }
     else{
         return false;
     }  
  }
}
