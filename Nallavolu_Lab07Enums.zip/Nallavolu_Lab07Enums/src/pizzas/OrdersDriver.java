/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzas;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * Class: 44542-02 Object Oriented Programming
 *
 * @author Tejaswi Reddy Nallavolu Description: Making sure everything works
 * Due: 03/24/21 I pledge that I have completed the programming assignment
 * independently. I have not copied the code from a student or any source. I
 * have not given my code to any other student and will not share this code with
 * anyone under my circumstances.
 */
public class OrdersDriver {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        Scanner scan = new Scanner(new File("input.txt"));
        System.out.println("*******************************"
                + "**********************");
        System.out.println("*********************** Pizza Hut "
                + "******************");
        System.out.println("******************************"
                + "***********************");

        while (scan.hasNext()) {
            OrdersSummary orderSum = new OrdersSummary();
            String orderDate = scan.nextLine();
            String pizzName = scan.nextLine().toUpperCase().replace(" ", "_");
            PizzaTypes pizzasName = PizzaTypes.valueOf(pizzName);
            String pizzasSize = scan.next().toUpperCase();
            int quantity = scan.nextInt();
            scan.nextLine();
            String sau = scan.nextLine().toUpperCase().replace(" ", "_");
            Sauces sauce = Sauces.valueOf(sau);
            String mystring = "";
            mystring = scan.nextLine();
            String t[] = mystring.split("-", 2);
            String tr = t[0].toUpperCase().trim().replace(" ", "_");
            Sides side = Sides.valueOf(tr);
            String sideSize = t[1].trim().toUpperCase();
            String chee = scan.nextLine().toUpperCase().replace(" ", "_");
            Sides.Cheese cheese = Sides.Cheese.valueOf(chee);
            String dri = scan.nextLine().toUpperCase().replace(" ", "_");
            Drinks drink = Drinks.valueOf(dri);
            String dess = scan.nextLine().toUpperCase().trim().replace(" ", "_");
            Desserts dessert = Desserts.valueOf(dess);
            Order order = new Order(pizzasName, pizzasSize, quantity, sauce, side, sideSize,
                    drink, cheese, dessert);
            orderSum.addAOrder(order);
            String or = orderSum.printReceipt(orderDate);
            System.out.println(or);

        }

    }

}
