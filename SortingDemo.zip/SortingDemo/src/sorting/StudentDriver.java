/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorting;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class StudentDriver {

    

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException{
        // TODO code application logic here
        ArrayList<Student>stuList = new ArrayList<>();
        Scanner scan = new Scanner(new File("input.txt"));
        while(scan.hasNext()){
            Student s=new Student(scan.nextInt(),scan.next(),scan.next(),scan.nextDouble());
            stuList.add(s);
        }
        System.out.println("Raw list");
        printList(stuList);
        System.out.println("*********************");
        System.out.println("Sorted based on last name");
        Collections.sort(stuList);
        
        printList(stuList);
        System.out.println("*******************************");
        System.out.println("Overriding the natural order sorting");
        Collections.sort(stuList,new Comparator<Student>() {
            @Override
            public int compare(Student s1, Student s2) {
               if (s1.getlName().compareTo(s2.getlName()) == 0) {
       return s1.getfName().compareTo(s2.getfName());
   } else {
     return s1.getlName().compareTo(s2.getlName());
   }
            }
        });
        printList(stuList);
          }//end main
    private static void printList(List<Student>sList){
        for(Student s:sList){
            System.out.println(s);
        }}}
   