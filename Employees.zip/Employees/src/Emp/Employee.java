/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Emp;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class Employee {
    private String name;
    private int id;
    private double salary;
    
    public Employee(String nameC,int idC,double salaryC){
        name=nameC;
        id=idC;
        salary=salaryC;
        
    }
    public String getName(){
        return name;
    }
    public int getID(){
        return id;
    }
    public void setName(String newName){
        name=newName;    
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
    
    public double bonus(){
        return salary*0.1;
    }
    
}
