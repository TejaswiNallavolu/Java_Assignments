/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Emp;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class JuniorDev extends Employee  {
    
    private String skill;

    public JuniorDev(String skill, String nameC, int idC, double salaryC) {
        super(nameC, idC, salaryC);
        this.skill = skill;
    }
    public String getSkill(){
        return skill;
    }
    
    public double bonus(){
        return super.bonus();
    }
    
    
}
