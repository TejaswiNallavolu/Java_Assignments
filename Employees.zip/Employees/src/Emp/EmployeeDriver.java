/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */`
package Emp;

import java.util.ArrayList;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class EmployeeDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Employee emp1 = new Employee("Teja", 1234, 2456.9);
//        System.out.println(emp.getSalary());
        Employee emp2 = new Employee("G1", 9870, 10000.9);
        Employee emp3 = new Employee("Tejaswi", 67989, 12000.9);
        Employee emp4 = new Employee("raghu", 8686, 1000.9);
        Employee emp5 = new Employee("abc", 8989, 3450.9);
      
        int[] arr=new int[6];
        
        for(int i=0;i<6;i++){
            arr[i]=emp1;
        }
        System.out.print(arr[0]+" ");
        for(int i=0;i<6;i++){
         System.out.print(arr[i]+" ");
      }
//        ArrayList<Employee> emps = new ArrayList<>();
//        emps.add(emp1);
//        emps.add(emp2);
//        emps.add(emp3);
//        emps.add(emp4);
//        emps.add(emp5);
//        for(int i=0;i<emps.size();i++){
//            System.out.println(emps.get(i).getSalary());
//        }
//        for (Employee e : emps) {
//            System.out.println(e.getName());
//            System.out.println(e.getSalary());
//            
//        }
        JuniorDev jd=new JuniorDev("Dve","jeeva",1234,1344500);
        System.out.println(jd.bonus());
//        System.out.println(emp1.getName());
    }
}
