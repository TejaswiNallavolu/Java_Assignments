/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beersales;
import java.util.*;
        
/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class Retailer {

    private String retailerName;
    private String address;
    private ArrayList<Beer> beerList;

    /**
     *
     * @param retailerName
     * @param address
     */
    public Retailer(String retailerName, String address) {
        this.retailerName = retailerName;
        this.address = address;
        this.beerList = new ArrayList<>();
    }

    /**
     *to get RetailerName
     * @return RetailerName
     */
    public String getRetailerName() {
        return retailerName;
    }

    /**
     *to get Address
     * @return Address
     */
    public String getAddress() {
        return address;
    }

    /**
     *to get arraylist
     * @return beerList
     */
    public ArrayList<Beer> getBeerList() {
        return beerList;
    }

    /**
     *to get isAvailable
     * @param beerName
     * @return boolean
     */
    public boolean isAvailable(String beerName) {
        for (Beer b : beerList) {
            if (b.getBeerName().equals(beerName)) {
                return true;
            }
        }
        return false;
    }

    /**
     *to get addNewBeer
     * @param newBeer
     */
    public void addNewBeer(Beer newBeer) {
        boolean flag = false;
        for (Beer b : beerList) {
            if (b.getBeerName().equals(newBeer.getBeerName())) {
                flag = true;
            }
        }
        if (!flag) {
            beerList.add(newBeer);
        }
    }

    /**
     *to get removeBeer
     * @param beerName
     * @return removeBeer
     */
    public Beer removeBeer(String beerName) {
        for (Beer b : beerList) {
            if (b.getBeerName().equals(beerName)) {
                beerList.remove(b);
                return b;
            }
        }
        return null;
    }

    /**
     *to get StrongBeers
     * @return StrongBeers
     */
    public ArrayList<Beer> getStrongBeers() {
        ArrayList<Beer> result = new ArrayList<Beer>();
        for (Beer b : beerList) {
            if (b.getAbv() > 4) {
                result.add(b);
            }
        }
        return result;
    }

    /**
     *to get LightBeers
     * @return result
     */
    public ArrayList<Beer> getLightBeers() {
        ArrayList<Beer> result = new ArrayList<Beer>();
        for (Beer b : beerList) {
            if (b.getAbv() <= 4) {
                result.add(b);
            }
        }
        return result;
    }

    /**
     *to get IndexinList
     * @param beerName
     * @return i
     */
    public int getIndexinList(String beerName) {
        for (int i = 0; i < beerList.size(); i++) {
            if (beerList.get(i).getBeerName().equals(beerName)) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public String toString() {
        String output;
        output = retailerName + "\n" + address + "\n*****Beers List*****\n"
                + "********************\n";
        for (Beer b : beerList) {
            output = output + b.toString();
        }

        return output + "\n********************\n";
    }

}
