/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beersales;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 * 
 */
public class SalesDriver {

    /**
     * @param args the command line arguments
     */
   public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        //1.Declare and initialize a Scanner object to read from the file "inputFile2.txt"
        Scanner scan = new Scanner(new File("inputFile1.txt"));
        //2.Declare and initialize a PrintWriter object to write output to the file "outputFileText2.txt"
        PrintWriter writer = new PrintWriter(new File("outputFileText1.txt"));
        //3.create an ArrayList of Retailer objects with name "retailers"
        ArrayList<Retailer> retailers = new ArrayList<>();
        //4.Read Data
        String beerName1 = "";
//        scan.nextLine();
        while (scan.hasNext()) { //Read line
            //5.Read Retailer name and address

            scan.nextLine();
            String rtName = scan.nextLine();

            String rtAddress = scan.nextLine();

            //6.Declare and initialize an object for retailer using above read values
            Retailer retailer = new Retailer(rtName, rtAddress);

            //7.Read all beers available for the retailer. Loop starts here
            do {
                //8.Read all details of a beer

                String beerName = "";
                if (beerName1.equals("Retailer")) {
                    beerName = scan.nextLine();
                } else {
                    beerName = beerName1 + scan.nextLine();
                }
                String beerStyle = scan.nextLine();
                String beerType = scan.next();
                double abv = scan.nextDouble();
                scan.nextLine();
                int[] packages = new int[10];
                int[] packSizes;
                int len = 0;
                while (scan.hasNextInt()) {
                    packages[len++] = scan.nextInt();
                }
                packSizes = new int[len];
                for (int i = 0; i < len; i++) {
                    packSizes[i] = packages[i];
                }

                // 9.Declare and initialize an object for Beer using above read values
                Beer addingBeer = new Beer(beerName, beerType, beerStyle, abv, packSizes);

                // 10.Add the declared beer object to retailer object created in the outer loop
                retailer.addNewBeer(addingBeer);
                if (scan.hasNext()) {
                    beerName1 = scan.next();
                }

            } while (scan.hasNext() && !beerName1.equals("Retailer"));
            //End the loop if reading all the Beer objects for a retailer is completed
            // 11.Add the retailer object created in this loop to variable retailers
            retailers.add(retailer);

        }

        /*!!!For bellow statements, use loops to retrive required Retailer object from arraylist "retailers"
             Do not hardcode indexes to retrive data from variable retailers*/
        // 12.Print "******Walmart Inventory for Beer's*****"
        System.out.println("***************************************");
        System.out.println("******Walmart Inventory for Beer's*****");
        System.out.println("***************************************");
        writer.println("***************************************");
        writer.println("******Walmart Inventory for Beer's*****");
        writer.println("***************************************");
        for (Retailer retailer : retailers) {
            if (retailer.getRetailerName().equals("Walmart")) {
                System.out.println(retailer);
                writer.println(retailer);
                break;
            }
        }

        System.out.println("***********************************");
        System.out.println("***Remove Wells IPA from Walmart****");
        System.out.println("***********************************");
        writer.println("***********************************");
        writer.println("***Remove Wells IPA from Walmart****");
        writer.println("***********************************");
        for (Retailer retailer : retailers) {
            if (retailer.getRetailerName().equals("Walmart")) {
                Beer removedBeer = retailer.removeBeer("Wells IPA");
                System.out.println(removedBeer);
                writer.println(removedBeer);
                break;
            }
        }
        // 16.Print "****List of strong beer from Hy-Vee****"
        System.out.println("***************************************");
        System.out.println("****List of strong beer from Hy-Vee****");
        System.out.println("***************************************");
        writer.println("***************************************");
        writer.println("****List of strong beer from Hy-Vee****");
        writer.println("***************************************");

        for (Retailer retailer : retailers) {
            if (retailer.getRetailerName().equals("Hy-Vee")) {
                ArrayList<Beer> beers = new ArrayList<>();
                beers = retailer.getStrongBeers();
                for (Beer beer : beers) {
                    System.out.println(beer);
                    writer.println(beer);
                }
                break;
            }
        }

        // 18.Print "****List of light beer from Sam's Club****"
        System.out.println("******************************************");
        System.out.println("****List of light beer from Sam's Club****");
        System.out.println("******************************************");
        writer.println("******************************************");
        writer.println("****List of light beer from Sam's Club****");
        writer.println("******************************************");
        for (Retailer retailer : retailers) {
            if (retailer.getRetailerName().equals("Sam's Club")) {
                ArrayList<Beer> beers = new ArrayList<>();
                beers = retailer.getLightBeers();
                for (Beer beer : beers) {
                    System.out.println(beer);
                    writer.println(beer);
                }
                break;
            }
        }
        // 20.Print  "****Count of different beers available from each retailer****"
        System.out.println("*************************************************************");
        System.out.println("****Count of different beers available from each retailer****");
        System.out.println("*************************************************************");
        writer.println("*************************************************************");
        writer.println("****Count of different beers available from each retailer****");
        writer.println("*************************************************************");
        for (Retailer retail : retailers) {
            System.out.println(retail.getRetailerName() + ": "
                    + retail.getBeerList().size());
            writer.println(retail.getRetailerName() + ": "
                    + retail.getBeerList().size());
        }
        // 21.Print count of different beers available from each retailer
        // 22.Print "****All different beers available from all retailers****"
        // 23.Print Names of all different beers from all retailers.
        System.out.println("***************************************************"
                + "*****");
        System.out.println("****All different beers available from all retailers"
                + "****");
        System.out.println("***************************************************"
                + "*****");
        writer.println("***************************************************"
                + "*****");
        writer.println("****All different beers available from all retailers"
                + "****");
        writer.println("***************************************************"
                + "*****");
        ArrayList<String> beers = new ArrayList<>();
        ArrayList<String> countbeers = new ArrayList<>();
        for (Retailer ret : retailers) {

            for (int i = 0; i < ret.getBeerList().size(); i++) {
                String beername = ret.getBeerList().get(i).getBeerName();
                beers.add(beername);
            }
        }
        for (String c : beers) {
            if (!(countbeers.contains(c))) {
                countbeers.add(c);
            }
        }

        for (int i = 0; i < countbeers.size(); i++) {
            System.out.println(countbeers.get(i));
            writer.println(countbeers.get(i));
        }

        // 23.Print Names of all different beers from all retailers.
        // 24.Close PrintWriter object
        writer.close();
    }
}

