/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beersales;

import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class Beer {

    private String beerName;
    private String beerType;
    private String beerStyle;
    private double abv;
    private int[] availablePackages;

    /**
     *
     * @param beerName
     * @param beerType
     * @param beerStyle
     * @param abv
     * @param availablePackages
     */
    public Beer(String beerName, String beerType, String beerStyle, double abv, int[] availablePackages) {
        this.beerName = beerName;
        this.beerType = beerType;
        this.beerStyle = beerStyle;
        this.abv = abv;
        this.availablePackages = availablePackages;
    }

    /**
     * to get BeerName
     * @return BeerName
     */
    public String getBeerName() {
        return beerName;
    }

    /**
     *to get BeerType
     * @return BeerType
     */
    public String getBeerType() {
        return beerType;
    }

    /**
     *to get BeerStyle
     * @return BeerStyle
     */
    public String getBeerStyle() {
        return beerStyle;
    }

    /**
     *to get Abv
     * @return Abv
     */
    public double getAbv() {
        return abv;
    }

    /**
     *to get AvailablePackages
     * @return AvailablePackages
     */
    public int[] getAvailablePackages() {
        return availablePackages;
    }
/**
 * it will return boolean
 * @return boolean
 */
    private boolean isLightBeer() {
        if (abv <= 0.04) {
            return true;
        } else {
            return false;
        }
    }
/**
 * to get tostring
 * @return tostring
 */
    public String toString() {
        String packs = "";
        for (int i = 0; i < this.availablePackages.length; i++) {
            if (i == this.availablePackages.length - 1) {
                packs += this.availablePackages[i] + ".";
            } else {
                packs += this.availablePackages[i] + ", ";
            }
        }
        return "\nBeer Name: " + this.beerName
                + "\nBeer Type: " + this.beerType
                + ", Beer Style: " + this.beerStyle
                + "\nabv: " + this.abv + "%"
                + "\nAvailable in packs of: " + packs+ "\n--------------------";
    }
}
