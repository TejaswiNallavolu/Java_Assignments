/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;
import java.util.*;
/**
 **Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
 * Description: Making sure everything works
 * Due: 03/17/21
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class Customer {
    private String dob;  //date of birth of customer(DD/MM/YYYY)
    private String firstName;  // first name of customer
    private String lastName;    // last name of customer
    
    /**augmented constructor class for customer
     * 
     * @param dob
     * @param firstName
     * @param lastName 
     */
 
    public Customer(String dob, String firstName, String lastName){
        this.dob = dob;
        this.firstName = firstName;
        this.lastName = lastName;
    }
    
    /**getter method for retrieving date of birth
     * 
     * @return dob
     */
    public String getdob(){
        return dob;
    }
    
    /**setter method for date of birth
     * 
     * @param dob 
     */
    public void setdob(String dob){
        this.dob = dob;
    }
    
    /**getter method for retrieving first name of the customer
     * 
     * @return firstName
     */
    public String getFirstName(){
        return firstName;
    }
    
    /**setter method for first name of the customer
     * 
     * @param firstName 
     */
    public void setFirstName(String firstName){
        this.firstName = firstName;
    }
    
    /**getter method for last name of customer
     * 
     * @return lastName
     */
    public String getLastName(){
        return lastName;
    }
    
    /**setter method for last name of the customer
     * 
     * @param lastName 
     */
    public void setLastName(String lastName){
        this.lastName = lastName;
    }

    /**toString method converts constructor customer to string
     * 
     * @return 
     */
    @Override
    public String toString() {
        return "Name:  " + lastName+", "+firstName+"\n" +"Date of Birth: " + dob;
    }

    String getDob() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
