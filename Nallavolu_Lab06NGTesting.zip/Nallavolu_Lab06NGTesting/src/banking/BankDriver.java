/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

/**
 * Class: 44542-02 Object Oriented Programming
 *
 * @author Tejaswi Reddy Nallavolu Description: Making sure everything works
 * Due: 03/17/21 I pledge that I have completed the programming assignment
 * independently. I have not copied the code from a student or any source. I
 * have not given my code to any other student and will not share this code with
 * anyone under my circumstances.
 */
public class BankDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, ParseException {
        // TODO code application logic here

        ArrayList<Account> accounts = new ArrayList<>();
        Scanner sc = new Scanner(new File("input.txt"));
        while (sc.hasNext()) {
            String line = "";
            String accountType = sc.nextLine();
            String firstName = sc.next();
            String lastName = sc.next();
            String date = sc.next();
            long accountNumber = sc.nextLong();
            boolean hasLimit = sc.nextBoolean();
            Customer C = new Customer(date, firstName, lastName);
            Account A = new Account(accountNumber, C, hasLimit);
            System.out.println("------------------------------------------------------------");
            System.out.println("Name of the customer: " + firstName + "  " + lastName);
            System.out.println("------------------------------------------------------------");
            while (sc.hasNext()) {
                String transactionType = sc.next();
                if ("DEPOSIT".equals(transactionType) || "WITHDRAW".equals(transactionType) || "ONLINEPURCHASE".equals(transactionType)) {
                    double tAmount = sc.nextDouble();
                    String tDate = sc.nextLine();
                    LocalDateTime Local;
                    if (tDate.matches("yyyy/M/dd HH:mm:ss")) {
                        Date date1 = new SimpleDateFormat("yyyy/M/dd HH:mm:ss").parse(tDate);
                        Local = LocalDateTime.ofInstant(date1.toInstant(),
                                ZoneId.systemDefault());
                    } else if (tDate.matches("yyyy/MM/dd H:mm:ss")) {
                        Date date1 = new SimpleDateFormat("yyyy/MM/dd H:mm:ss").parse(tDate);
                        Local = LocalDateTime.ofInstant(date1.toInstant(),
                                ZoneId.systemDefault());
                    } else if (tDate.matches("yyyy/MM/dd HH:mm:s")) {
                        Date date1 = new SimpleDateFormat("yyyy/MM/dd HH:mm:s").parse(tDate);
                        Local = LocalDateTime.ofInstant(date1.toInstant(),
                                ZoneId.systemDefault());
                    } else {
                        Date date1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(tDate);
                       Local = LocalDateTime.ofInstant(date1.toInstant(),
                                ZoneId.systemDefault());
                    }
                    Transaction t = new Transaction(transactionType, tAmount, Local);
                    String status = A.makeTransaction(t);
                    double Amount = A.getBalance();
                    Amount = Math.round(Amount * 100) / 100.00;
                    String str = String.format("%1.2f", Amount);
                    switch (status) {
                        case ("Insufficient Balance"):
                            System.out.println("Insufficient funds. Available funds: " + str);
                            break;
                        case ("MaxTransactions"):
                            System.out.println("Exceeded number of withdrawals transactions. Number of available withdrawals per month: 6");
                            break;
                        case ("Transaction Successful"):
                            System.out.println("The balance after " + transactionType + " in dollars is " + str);
                            break;
                    }
                } else {
                    int cd = 1;
                    break;
                }
            }
            accounts.add(A);
        }
        System.out.println("************************************************************************\n"
                + "*********Invoke getNoofWithdrawals() on Account objects**********\n"
                + "************************************************************************");
        for (Account i : accounts) {
            int j = i.getNoofWithdrawals();
            String firstName = i.getCustomer().getFirstName();
            System.out.println(firstName + " made " + j + " withdrawals in this month.");
        }
        System.out.println("***********************************************************************\n"
                + "****Invoke generateStatement() on all objects in accounts ArrayList****\n"
                + "************************************************************************");
        for (Account j : accounts) {
            String i = j.generateStatement();
            System.out.println(i);
        }
    }

}
