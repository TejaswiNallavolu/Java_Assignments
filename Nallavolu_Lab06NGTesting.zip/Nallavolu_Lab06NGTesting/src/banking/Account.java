/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.text.SimpleDateFormat;
import java.time.*;
import java.util.*;

/**
 * Class: 44542-02 Object Oriented Programming
 *
 * @author Tejaswi Reddy Nallavolu Description: Making sure everything works
 * Due: 03/17/21 I pledge that I have completed the programming assignment
 * independently. I have not copied the code from a student or any source. I
 * have not given my code to any other student and will not share this code with
 * anyone under my circumstances.
 */
public class Account {

    private long accountNumber;     
    private Customer customer;     
    private double balance;         
    private ArrayList<Transaction> transactions = new ArrayList<>();  
    private boolean hasLimitedWithdrawals; 
    static final double SAVING_INTEREST = 5.80;

    /**
     * constructor class for the account
     *
     * @param accountNumber
     * @param customer
     * @param hasLimitedWithdrawals
     */
    public Account(long accountNumber, Customer customer, boolean hasLimitedWithdrawals) {
        this.accountNumber = accountNumber;
        this.customer = customer;
        this.hasLimitedWithdrawals = hasLimitedWithdrawals;
    }

    /**
     * getter method for account number of customer
     *
     * @return accountNumber
     */
    public long getAccountNumber() {
        return accountNumber;
    }

    /**
     * getter method for retrieving the customer
     *
     * @return customer
     */
    public Customer getCustomer() {
        return customer;
    }

    /**
     * getter method for withdrawal limit
     *
     * @return hasLimitedWithdrawals
     */
    public boolean isHasLimitedWithdrawals() {
        return hasLimitedWithdrawals;
    }

    /**
     * getter method for balance
     *
     * @return balance
     */
    public double getBalance() {

        return balance;
    }

    /**
     * setter method for balance
     *
     * @param balance
     */
    public void setBalance(double balance) {
        this.balance = balance;

    }

    String statement = "";

    /**
     * method used to generate the statement
     *
     * @return statement
     */
    public String generateStatement() {
        statement = customer.toString() + "\nAccount Number: " + accountNumber
                + "\nAccount Information:-        Interest Rate: 5.80%\n";
        if (this.hasLimitedWithdrawals == true) {
            statement = statement + "Transaction Limit for withdrawal: " + "7 Transactions\n";
        } else {
            statement = statement + "Transaction Limit for withdrawal: No Limit\n";
        }
        String t = transactions.toString();
        t = t.replace("[", "").replace("]", "").replace(",", "");
        t = t.replace("\n ", "\n");
        statement = statement + "-------------------------------------------------------------------------------\n"
                + "Transaction Type    Transaction Time         Amount          Additional Charges       Status    \n";
        statement = statement + t;
        statement = statement + "-------------------------------------------------------------------------------";

        int s = transactions.size() - 1;
        double m = getBalance();
        m = Math.round(m * 100) / 100.00;
        String str = String.format("%1.2f", m);
        double i = m * 0.058;
        i = Math.round(i * 100) / 100.00;
        statement = statement + "\nCurrent Balance: " + str + "                Interest: $" + i;
        statement = statement + "\n************************************************************************";

        return statement;
    }

    /**
     * method returns number of withdrawals
     *
     * @return noOfWithDrawals
     */
    public int getNoofWithdrawals() {
        int withdraw = 0;
        LocalDateTime localDate = LocalDateTime.now();
        for (Transaction t : transactions) {
            LocalDateTime td = t.getTransactionTime();
            if ("WITHDRAW".equals(t.getTransactionType()) && td.
                    getMonthValue() == LocalDateTime.now().getMonthValue()) {
                withdraw++;
            }
        }
        return withdraw;
    }

    String status = "";

    /**
     * method for transaction object
     *
     * @param transaction
     * @return status
     */
    public String makeTransaction(Transaction transaction) {
        double x = getBalance();
        if (("WITHDRAW".equals(transaction.getTransactionType())
                || "ONLINEPURCHASE".equals(transaction.getTransactionType()))
                && (getBalance() < transaction.getAmount())) {
            transaction.setAdditionalCharges(0.0);
            transaction.setAmount(transaction.getAmount());
            transaction.setStatus("FAILED");
            status = "Insufficient Balance";
            transactions.add(transaction);
            return status;
        }
        if ("DEPOSIT".equals(transaction.getTransactionType())) {
            transaction.setAdditionalCharges(0.0);
            transaction.setStatus("SUCCESS");
            double balance = getBalance() + transaction.getAmount();
            setBalance(balance);
            transaction.setAmount(transaction.getAmount());
            status = "Transaction Successful";
            transactions.add(transaction);
            return status;
        }
        if ("ONLINEPURCHASE".equals(transaction.getTransactionType())) {
            transaction.setAdditionalCharges(1.99);
            transaction.setStatus("SUCCESS");
            double balance = getBalance() - (transaction.getAmount() + transaction.getAdditionalCharges());
            double a = transaction.getAmount();
            setBalance(balance);
            transaction.setAmount(a);
            status = "Transaction Successful";
            transactions.add(transaction);
            return status;
        }
        if ("WITHDRAW".equals(transaction.getTransactionType())) {
            if (getBalance() > transaction.getAmount() && this.hasLimitedWithdrawals == false) {
                if (getNoofWithdrawals() >= 6) {
                    double onePercent = transaction.getAmount() * 0.01;
                    if (onePercent > 2.59) {
                        transaction.setAdditionalCharges(onePercent);
                    } else {
                        transaction.setAdditionalCharges(2.59);
                    }
                    double balance = getBalance() - (transaction.getAmount() + transaction.getAdditionalCharges());
                    transaction.setAmount(transaction.getAmount());
                    setBalance(balance);
                    transaction.setStatus("SUCCESS");
                    status = "Transaction Successful";
                    transactions.add(transaction);
                    return status;
                } else {
                    transaction.setAdditionalCharges(0.0);
                    double balance = getBalance() - (transaction.getAmount() + transaction.getAdditionalCharges());
                    transaction.setAmount(transaction.getAmount());
                    setBalance(balance);
                    transaction.setStatus("SUCCESS");
                    status = "Transaction Successful";
                    transactions.add(transaction);
                    return status;
                }
            }
            if (balance > transaction.getAmount() && this.hasLimitedWithdrawals == true) {
                int NW = getNoofWithdrawals();
                if (NW >= 6) {
                    transaction.setAdditionalCharges(0.0);
                    transaction.setStatus("FAILED");
                    double balance = getBalance();
                    setBalance(balance);
                    transaction.setAmount(transaction.getAmount());
                    status = "MaxTransactions";
                    transactions.add(transaction);
                    return status;
                } else {
                    transaction.setAdditionalCharges(0.0);
                    double balance = getBalance() - transaction.getAmount();
                    transaction.setAmount(transaction.getAmount());
                    setBalance(balance);
                    transaction.setStatus("SUCCESS");
                    status = "Transaction Successful";
                    transactions.add(transaction);
                    return status;
                }
            }

        }
        transactions.add(transaction);
        return status;
    }

}
