/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;
import java.text.DecimalFormat;
import java.time.LocalDateTime;

/**
 * Class: 44542-02 Object Oriented Programming
 * @author Tejaswi Reddy Nallavolu
Description: Making sure everything works
 * Due: 03/17/21
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any other student and will not share this code with anyone under my circumstances.
 */
public class Transaction {
    private double additionalCharges;   
    private double amount;     
    private String status;      
    private LocalDateTime transactionTime;      
    private String transactionType;             
    
    /**constructor class for the transaction details of the customer
     * 
     * @param transactionType
     * @param amount
     * @param transactionTime 
     */
    public Transaction(String transactionType, double amount, LocalDateTime transactionTime){
        this.transactionType = transactionType;
        this.amount = amount;
        this.transactionTime = transactionTime;
    }

    /**getter method for retrieving additional charges for the transaction
     * 
     * @return additionalCharges
     */
    public double getAdditionalCharges() {
        return additionalCharges;
    }

    /**setter method for additional charges for the transaction
     * 
     * @param additionalCharges 
     */
    public void setAdditionalCharges(double additionalCharges) {
        this.additionalCharges = additionalCharges;
    }

    /**getter method for retrieving the transaction amount
     * 
     * @return amount
     */
    public double getAmount() {
        return amount;
    }
    
    /**setter method to set the transaction amount
     * 
     * @param amount 
     */

    public void setAmount(double amount) {
        this.amount = amount;
    }

    /**getter method to retrieve the status of transaction
     * 
     * @return status
     */
    public String getStatus() {
        return status;
    }

    /**setter method for the status of transaction
     * 
     * @param status 
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**getter method to retrieve the transaction time
     * 
     * @return trnasctionTime
     */
    public LocalDateTime getTransactionTime() {
        return transactionTime;
    }

    /**setter method for the transaction time
     * 
     * @param transactionTime 
     */
    public void setTransactionTime(LocalDateTime transactionTime) {
        this.transactionTime = transactionTime;
    }

    /**getter method to retrieve the type of transaction
     * 
     * @return transactionType
     */
    public String getTransactionType() {
        return transactionType;
    }

    /**setter method to set type of transaction
     * 
     * @param transactionType 
     */
    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

   
    /** tostring method for transaction constructor
     * 
     * @return 
     */
    @Override
    public String toString() {
         int T = 17 - transactionType.length();
         String str = String.format("%1.2f", amount);
         int R=16 - str.length();
         String N = String.format("%1.2f", additionalCharges);         
          String S ="";
         if(status == "FAILED"){
              S =" ";
         }
        return transactionType+ "   "+String.format("%" + T+ "s", "") 
                +  transactionTime + "      "+ str+ String.format("%" + R + "s", "")
                +N+"                     "+  status + S+"   \n";
    }
    

    
}


