/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.time.LocalDateTime;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class TransactionNGTest {
    
    public TransactionNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    /**
     * Test of getAdditionalCharges method, of class Transaction.
     */
    @Test
    public void testGetAdditionalCharges() {
        System.out.println("getAdditionalCharges");
        Transaction transaction;
        transaction = new Transaction("Deposit", 100.0,LocalDateTime.now());
        double expResult = 0.0;
        double result = transaction.getAdditionalCharges();
        assertEquals(result, expResult, 0.0);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of setAdditionalCharges method, of class Transaction.
     */
    @Test
    public void testSetAdditionalCharges() {
        System.out.println("setAdditionalCharges");
        double additionalCharges = 0.0;
        Transaction transaction;
        transaction = new Transaction("Deposit", 100.0,LocalDateTime.now());
        transaction.setAdditionalCharges(additionalCharges);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    
    /**
     * Test of setAmount method, of class Transaction.
     */
    @Test
    public void testSetAmount() {
        System.out.println("setAmount");
        double amount = 0.0;
        Transaction transaction;
        transaction = new Transaction("Deposit", 100.0,LocalDateTime.now());
        transaction.setAmount(amount);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of getStatus method, of class Transaction.
     */
    @Test
    public void testGetStatus() {
        System.out.println("getStatus");
        Transaction transaction;
        transaction = new Transaction("Deposit", 100.0,LocalDateTime.now());
        String expResult = null;
        String result = transaction.getStatus();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setStatus method, of class Transaction.
     */
    @Test
    public void testSetStatus() {
        System.out.println("setStatus");
        String status = "";
        Transaction transaction;
        transaction = new Transaction("Deposit", 100.0,LocalDateTime.now());;
        transaction.setStatus(status);
        // TODO review the generated test code and remove the default call to fail.
     //   fail("The test case is a prototype.");
    }

    /**
     * Test of getTransactionTime method, of class Transaction.
     */
    @Test
    public void testGetTransactionTime() {
        System.out.println("getTransactionTime");
        Transaction transaction;
        transaction = new Transaction("Deposit", 100.0,LocalDateTime.now());
        LocalDateTime expResult = LocalDateTime.now();
        LocalDateTime result = transaction.getTransactionTime();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of setTransactionTime method, of class Transaction.
     */
    @Test
    public void testSetTransactionTime() {
        System.out.println("setTransactionTime");
        LocalDateTime transactionTime = LocalDateTime.now();
        Transaction transaction;
        transaction = new Transaction("Deposit", 100.0,LocalDateTime.now());
        transaction.setTransactionTime(transactionTime);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getTransactionType method, of class Transaction.
     */
    @Test
    public void testGetTransactionType() {
        System.out.println("negative getTransactionType");
        Transaction transaction;
        transaction = new Transaction("TEJU", 100.0,LocalDateTime.now());
        String expResult = "TEJU";
        String result = transaction.getTransactionType();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    
    /**
     * Test of setTransactionType method, of class Transaction.
     */
    @Test
    public void testSetTransactionType() {
        System.out.println("setTransactionType");
        String transactionType = "TEJU";
        Transaction transaction;
        transaction = new Transaction("Deposit", 100.0,LocalDateTime.now());
        transaction.setTransactionType(transactionType);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class Transaction.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Transaction t = new Transaction("Deposit", 100.0,LocalDateTime.MIN);
        String expResult = "";
        String result = "";
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }
    
}
