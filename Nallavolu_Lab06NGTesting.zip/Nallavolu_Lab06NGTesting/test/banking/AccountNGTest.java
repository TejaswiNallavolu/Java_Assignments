/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;



/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class AccountNGTest {
    
    public AccountNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    /**
     * Test of getAccountNumber method, of class Account.
     */
    @Test
    public void testGetAccountNumber() {
        System.out.println("getAccountNumber");
        Customer c = new Customer("09/23/1994","Clint","Barton");
        Account instance = new Account(12312,c,false);
        long expResult = 12312;
        long result = instance.getAccountNumber();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of getCustomer method, of class Account.
     */
    @Test
    public void testGetCustomer() {
        System.out.println("getCustomer");
        Customer c = new Customer("09/23/1994","Clint","Barton");
        Account instance = new Account(12312,c,false);
        Customer expResult = c;
        Customer result = instance.getCustomer();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of isHasLimitedWithdrawals method, of class Account.
     */
    @Test
    public void testIsHasLimitedWithdrawals() {
        System.out.println("isHasLimitedWithdrawals");
        Customer c = new Customer("09/23/1994","Clint","Barton");
        Account instance = new Account(12312,c,false);
        boolean expResult = false;
        boolean result = instance.isHasLimitedWithdrawals();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getBalance method, of class Account.
     */
    @Test
    public void testGetBalance() {
        System.out.println("getBalance");
        Customer c = new Customer("07/18/1998","Tejaswi","Nallavolu");
        Account instance = new Account(12312,c,false);
        double expResult = 1.0;
        double result = instance.getBalance();
        assertEquals(result, expResult, 1.0);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setBalance method, of class Account.
     */
    @Test
    public void testSetBalance() {
        System.out.println("setBalance");
        Customer c = new Customer("07/18/1998","Tejaswi","Nallavolu");
        Account instance = new Account(12312,c,false);
        double balance = 0.0;
        instance.setBalance(balance);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of generateStatement method, of class Account.
     */
    @Test
    public void testGenerateStatement() {
        System.out.println("generateStatement");
        Customer c = new Customer("09/23/1994","Clint","Barton");
        Account instance = new Account(12312,c,false);
        String expResult = instance.generateStatement();
        String result = instance.generateStatement();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getNoofWithdrawals method, of class Account.
     */
    @Test
    public void testGetNoofWithdrawals() {
        System.out.println("getNoofWithdrawals");
        Customer c = new Customer("09/23/1994","Clint","Barton");
        Account instance = new Account(12312,c,false);
        int expResult = 0;
        int result = instance.getNoofWithdrawals();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of makeTransaction method, of class Account.
     */
    @Test
    public void testMakeTransaction() {
        System.out.println("makeTransaction");
        Transaction transaction;
        transaction = new Transaction("Deposit", 1001.0,LocalDateTime.now());
        Customer c = new Customer("09/23/1994","Clint","Barton");
        Account instance = new Account(12312,c,false);
        String expResult = "";
        String result = instance.makeTransaction(transaction);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }
    /**
     * Test of toString method, of class Transaction.
     */
    @Test
    public void testToString() {
//        System.out.println("toString");
       Transaction instance;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-M-d H:m:s");
        String time1 = "2021-07-01 12:01:54";
        instance = new Transaction("DEPOSIT", 3000.00,LocalDateTime.parse(time1, formatter));
        instance.setStatus("SUCCESS");
        DecimalFormat df = new DecimalFormat("#0.00");
        String expResult = String.format("%-19s %-24s %-15s %-24s %-10s","DEPOSIT","2021-07-01T12:01:54","3000.00","0.00","SUCCESS");
        String result = instance.toString();
        assertEquals(result.trim(), expResult.trim());
        
        
        
        
    
    
}

}
