/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accounts;
import enums.TransactionType;
import exceptions.InsufficentFundsException;
import exceptions.MaxTransactionsException;
import java.time.LocalDateTime;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class SavingsAccount extends Account  {
    boolean hasLimitedWithdrawals;
/**
     * this is a constructor
     * @param customer 
     * @param accountNumber
     * @param hasLimitedWithdrawals 
     */
    public SavingsAccount(Customer customer, long accountNumber, boolean 
            hasLimitedWithdrawals) {
        super(customer, accountNumber);
        this.hasLimitedWithdrawals = hasLimitedWithdrawals;
    }
    
    /**
     * method for generate statement
     * @return statement 
     */
    public String generateStatement(){
        String stat=toString();
        for(Transaction t1: transactions)
            stat+="\n"+t1.toString();
        return stat+"\n--------------------------------------------------------"
                + "-----------------------\nCurrent Balance: "+
                String.format("%.2f", balance)
         +"\t\tInterest: $"+String.format("%.2f", (balance*5.8*100/100)/100.0);
    }
    
    /**
     * getter method for number of withdrawals
     * @return number of withdrawals 
     */
    public int getNoofWithdrawals(){
        int withdrawals = 0;
        for (Transaction i : transactions) {
            if (i.getTransactionType().toString().contentEquals
        (TransactionType.valueOf("WITHDRAW").toString()) && 
       (i.getTrannsactionTime().getMonthValue() == LocalDateTime.now().
               getMonthValue())) {
                withdrawals++;
            }
        }
        return withdrawals;
    }
    
    /**
     * method for performing transaction and adding it to array list
     * @param transaction
     * @return transaction of the customer
     * @throws Exception
     */
    public double makeTransaction(Transaction transaction) throws Exception{
        try{
            
        double add_charge;
        if (transaction.getTransactionType().toString().contentEquals
        (TransactionType.valueOf("DEPOSIT").toString())) {
            balance += transaction.getAmount();
            transaction.setStatus("SUCCESS");
            transaction.additionalCharges=0.0;
            transactions.add(transaction);
       System.out.println("The balance after "+transaction.getTransactionType()
                    +" in dollars is "+String.format("%.2f", balance));
        } 
        else if (transaction.getTransactionType().toString().contentEquals
        (TransactionType.valueOf("ONLINEPURCHASE").toString())) {
            if (transaction.getAmount()+1.99 <= balance) {
                balance = balance - (transaction.getAmount() + 1.99);
                transaction.setStatus("SUCCESS");
                transaction.additionalCharges=1.99;
                transactions.add(transaction);
                System.out.println("The balance after "+transaction.
               getTransactionType()+" in dollars is "+String.format("%.2f", 
                       balance));
            } 
            else {
                transaction.setStatus("FAILED");
                transaction.additionalCharges=0.0;
                transactions.add(transaction);
              throw new InsufficentFundsException("InsufficentFundsException");
            }
        } 
        else if (transaction.getTransactionType().toString().contentEquals
        (TransactionType.valueOf("WITHDRAW").toString())) {
            if (balance >= transaction.getAmount() && hasLimitedWithdrawals) {
                if (getNoofWithdrawals() > 6) {
                    transaction.setStatus("FAILED");
                    transaction.additionalCharges=0.0;
                    transactions.add(transaction);
                throw new MaxTransactionsException("MaxTransactionsException");
                } 
                else {
                    balance -= transaction.getAmount();
                    transaction.setStatus("SUCCESS");
                    transaction.additionalCharges=0.0;
                    transactions.add(transaction);
                }
            } 
         else if (balance >= transaction.getAmount() && !hasLimitedWithdrawals)
         {
                if (getNoofWithdrawals() > 6) {
                    add_charge = 0.0;
                    double onep = transaction.getAmount() * 0.01;
                    if (onep > 2.59) {
                        add_charge = onep;
                    } 
                    else {
                        add_charge = 2.59;
                    }
                    balance = balance - (transaction.getAmount() + add_charge);
                    transaction.setStatus("SUCCESS");
                    transaction.additionalCharges=add_charge;
                    transactions.add(transaction);
                } 
                else {
                    balance -= transaction.getAmount();
                    transaction.setStatus("SUCCESS");
                    transaction.additionalCharges=0.0;
                    transactions.add(transaction);
                }
            } 
            else {
                transaction.setStatus("FAILED");
                transaction.additionalCharges=0.0;
                transactions.add(transaction);
              throw new InsufficentFundsException("InsufficentFundsException");
                
            }
            System.out.println("The balance after "+transaction.
                    getTransactionType()+" in dollars is "
                    +String.format("%.2f", balance));
        }
        }
        catch(InsufficentFundsException funds){
            System.out.println("exceptions."+funds.getMessage());
        }
        catch(MaxTransactionsException max){
            System.out.println("exceptions."+max.getMessage());
        }
        return Math.round(balance * 100) / 100.0;
    }

     /**
     * this is a to string method
     * @return details
     */    
    @Override
    public String toString() {
        String stat="Transaction Limit for withdrawal: No Limit";
        if(hasLimitedWithdrawals){
            stat="Transaction Limit for withdrawal: 6 Transactions";
        }
        return super.generateStatement()+"Account Type: Savings Account\t"
                + "Interest Rate: 5.80%\n"+stat
                +"\n----------------------------------"
                + "---------------------------------------------\n"
                +String.format("%-24s", "Transaction Type")
                +String.format("%-24s", "Transaction Time")
                +String.format("%-14s", "Amount")
                +String.format("%-27s", "Additional Charges")
                +String.format("%-8s", "Status");
    }
    
}


