/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accounts;
import enums.TransactionType;
import java.time.LocalDateTime;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class Transaction {
    double additionalCharges;
    double amount;
    String status;
    LocalDateTime trannsactonTime;
    TransactionType transactionType;

    /**
     * this is a constructor
     * @param transactionType 
     * @param amount
     * @param trannsactonTime 
     */
    public Transaction(TransactionType transactionType, double amount, 
            LocalDateTime trannsactonTime) {
        this.amount = amount;
        this.trannsactonTime = trannsactonTime;
        this.transactionType = transactionType;
    }

    /**
     * getter method for additional charges
     * @return additional charges 
     */
    public double getAdditionalCharges() {
        return additionalCharges;
    }

    /**
     * getter method for amount
     * @return amount 
     */
    public double getAmount() {
        return amount;
    }

    /**
     * getter method for status
     * @return status 
     */
    public String getStatus() {
        return status;
    }

    /**
     * getter method for transaction time
     * @return transaction time 
     */
    public LocalDateTime getTrannsactionTime() {
        return trannsactonTime;
    }

    /**
     * getter method for transaction type
     * @return transaction type of the customer
     */
    public TransactionType getTransactionType() {
        return transactionType;
    }

    /**
     * setter method for additional charges
     * @param additionalCharges 
     */
    public void setAdditionalCharges(double additionalCharges) {
        this.additionalCharges = additionalCharges;
    }

    /**
     * setter method for status
     * @param status set the status
     */
    public void setStatus(String status) {
        this.status = status;
    }

      /**
     * this is a to string method
     * @return details 
     */    
    @Override
    public String toString() {
        return String.format("%-24s", getTransactionType())
      +String.format("%-24s", getTrannsactionTime())
      +String.format("%-14s", "$"+String.format("%.2f", getAmount()))
      +String.format("%-27s", "$"+String.format("%.2f",getAdditionalCharges()))
      +String.format("%-8s", getStatus());
    }
    
}
