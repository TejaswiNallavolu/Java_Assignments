/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accounts;
import enums.TransactionType;
import exceptions.OverdraftLimitExceededException;
import static interfaces.Operations.OVERDRAFT_LIMIT;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class CurrentAccount extends Account{
    /**
     * this is a constructor
     * @param customer is a parameter
     * @param accountNumber is a parameter
     */
    public CurrentAccount(Customer customer, long accountNumber) {
        super(customer, accountNumber);
    }
    
    /**
     * method for statement generation
     * @return statement of the customer
     */
    public String generateStatement(){
        double draftusage=0;
        double available=500;
        if(balance<0){
            draftusage=Math.abs(balance);
            available=OVERDRAFT_LIMIT-draftusage;
            
        }
        String statement=toString();
        for(Transaction t1: transactions)
            statement+="\n"+t1.toString();
        if(balance<0){
            return statement+"\n-----------------------------------------------"
                    + "-----"+ "---------------------------\nCurrent Balance: "
                    +String.format("%.2f", balance-balance)+"\nOverdraft usage:"
              + " $"+String.format("%.2f",(draftusage))+"\t\tOverdraft availab"
                    + "le: $"+String.format("%.2f",(available));
        }
        else{
            return statement+"\n----------------------------------------------"
                    + "------"
                    + "---------------------------\nCurrent Balance: "+
                    String.format("%.2f", balance)+"\nOverdraft usage: $"
                +String.format("%.2f",(draftusage))+"\t\tOverdraft available"+ 
                    ": $"+String.format("%.2f",(available));
        }
    }
    
    /**
     * method for transaction and adding it to array list
     * @param transaction
     * @return transactions 
     * @throws Exception
     */
    public double makeTransaction(Transaction transaction) throws Exception{
        try{
        transaction.setStatus("SUCCESS");
        if(transaction.getTransactionType().toString().contentEquals(
                TransactionType.valueOf("DEPOSIT").toString())){
            balance+=transaction.getAmount();
            System.out.println("The balance after "+transaction.
                    getTransactionType()+" in dollars is "+String.format("%.2f",
                            balance));
        }
        else if(transaction.getTransactionType().toString().contentEquals(
                TransactionType.valueOf("WITHDRAW").toString())||transaction.
                        getTransactionType().toString().contentEquals(
                 TransactionType.valueOf("ONLINEPURCHASE").toString())){
            if(balance+OVERDRAFT_LIMIT<transaction.getAmount()){
                transaction.additionalCharges=0.0;
                transaction.setStatus("FAILED");
                transactions.add(transaction);
                throw new OverdraftLimitExceededException("overdraftLimitExcee"
                        + "dedException");
            }
            else{
                if(transaction.getTransactionType().toString().contentEquals(
                        TransactionType.valueOf("WITHDRAW").toString())){
                    if(balance+OVERDRAFT_LIMIT>transaction.getAmount()){
                        balance-=transaction.getAmount();
                        transaction.additionalCharges=0.0;
                        System.out.println("The balance after "+transaction.
                       getTransactionType()+" in dollars is "+
                                String.format("%.2f", balance));
                    }                        
                }
                else{
                    if(balance+OVERDRAFT_LIMIT>transaction.getAmount()){
                        balance-=(transaction.getAmount()+1.59);
                        transaction.additionalCharges=1.59;
                        System.out.println("The balance after "+transaction.
                        getTransactionType()+" in dollars is "+String.format
                        ("%.2f", balance));
                    }
                }   
            }
        }
        transactions.add(transaction);
        }
        catch(OverdraftLimitExceededException od){
            System.out.println("exceptions."+od.getMessage());
        } 
        return balance;
    }
    

    /**
     * this is a tostring method
     * @return details 
     */ 
    @Override
    public String toString() {
        return super.generateStatement()+"Account Type: Current Account\t"
                + "Overdraft Limit: $500.00"
                +"\n-------------------------------------"
                + "------------------------------------------\n"
                +String.format("%-24s", "Transaction Type")
                +String.format("%-24s", "Transaction Time")
                +String.format("%-14s", "Amount")
                +String.format("%-27s", "Additional Charges")
                +String.format("%-8s", "Status");
    }
    
    
}


