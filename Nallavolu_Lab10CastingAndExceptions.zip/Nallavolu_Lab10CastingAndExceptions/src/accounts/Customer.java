/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accounts;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class Customer {
    String dob;
    String firstName;
    String lastName;
/**
     * this is a constructor
     * @param firstName of the customer 
     * @param lastName of the customer 
     * @param dob of the customer 
     */
    public Customer(String firstName, String lastName, String dob) {
        this.dob = dob;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    /**
     * getter method for dob
     * @return dob
     */
    public String getDob() {
        return dob;
    }

    /**
     * getter method for first name
     * @return first name 
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * getter method for last name
     * @return last name 
     */
    public String getLastName() {
        return lastName;
    }

     /**
     * this is a toString method
     * @return details
     */    
    @Override
    public String toString() {
        return "Name:"+getLastName()+", "+getFirstName()+"\n"+
                "Date of Birth: "+getDob();
    }  
}
