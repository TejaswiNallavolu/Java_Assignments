/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accounts;

import interfaces.Operations;
import java.util.ArrayList;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public abstract class Account implements Operations {


    long accountNumber;
    double balance;
    Customer customer;
    ArrayList<Transaction> transactions;

    /**
     * this is a constructor
     *
     * @param customer 
     * @param accountNumber 
     */
    public Account(Customer customer, long accountNumber) {
        this.accountNumber = accountNumber;
        this.customer = customer;
        this.transactions = new ArrayList<Transaction>();
    }

    /**
     * getter method for account number
     *
     * @return account number 
     */
    public long getAccountNumber() {
        return accountNumber;
    }

    /**
     * getter method for balance
     *
     * @return balance of customer
     */
    public double getBalance() {
        return balance;
    }

    /**
     * getter method for customer
     *
     * @return customer details
     */
    public Customer getCustomer() {
        return customer;
    }

    /**
     * getter method for transactions
     *
     * @return transactions of the customer
     */
    public ArrayList<Transaction> getTransactions() {
        return transactions;
    }

    /**
     * method for generating statement
     *
     * @return customer details with account number
     */
    public String generateStatement() {
        return customer.toString() + "\nAccount Number: " + accountNumber + "\n";
    }

    /**
     * method for performing transaction
     *
     * @param transaction 
     * @return
     * @throws Exception
     */
    public abstract double makeTransaction(Transaction transaction) throws
            Exception;

    /**
     * this is a tostring method
     *
     * @return details
     */
    @Override
    public String toString() {
        return customer.toString() + "Account Number: " + getAccountNumber();
    }

}
