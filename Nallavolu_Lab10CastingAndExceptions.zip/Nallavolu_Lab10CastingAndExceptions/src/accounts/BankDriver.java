/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accounts;
import enums.TransactionType;
import java.io.File;
import java.io.FileNotFoundException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class BankDriver {

    /**
     * @param args
     * throws FileNotFoundException 
     */
    public static void main(String[] args) throws FileNotFoundException {

        // TODO code application logic here
    
        ArrayList<Account> accounts = new ArrayList<Account>();
        ArrayList<SavingsAccount> sa=new ArrayList<SavingsAccount>();
        Scanner s = new Scanner(new File("input.txt"));
        SavingsAccount saccount=null;
        CurrentAccount caccount=null;
        while (s.hasNext()) {
            String accountType=s.nextLine();
            String firstName = s.next();
            String lastName = s.nextLine();
            String dob = s.nextLine();
            Customer cust = new Customer(firstName, lastName, dob);
            long accountNumber = s.nextLong();
            s.nextLine();
            if(accountType.equalsIgnoreCase("savings")){
                boolean hasLimitedWithdrawals = s.nextBoolean();
                s.nextLine();
                saccount =new SavingsAccount(cust,accountNumber,
                        hasLimitedWithdrawals);
            }
            caccount = new CurrentAccount(cust,accountNumber);
            System.out.println("--------------------------------------------"
                  + "----------------\n"
                 + "Name of the customer: " + firstName + " " + lastName + "\n"
             + "------------------------------------------------------------");
            while(!s.hasNext("current")&&!s.hasNext("savings")){
                TransactionType transactionType = TransactionType.valueOf
        (s.next().toUpperCase());
                double amount = s.nextDouble();
                String time = s.nextLine().trim().replaceAll(" ", "T");
                LocalDateTime transactionTime = LocalDateTime.parse(time, 
                        DateTimeFormatter.ofPattern("yyyy-M-d'T'H:m:s"));
                Transaction t = new Transaction(transactionType, amount, 
                        transactionTime);
                try{
                    if(accountType.equalsIgnoreCase("Savings")){
                        saccount.makeTransaction(t);
                    }
                    else if(accountType.equalsIgnoreCase("current")){
                        caccount.makeTransaction(t);
                    }  
                }
                catch(Exception e){
                    System.out.println("Transaction could not be competed:"+
                            e.getMessage());
                }
                if(s.hasNext())
                    continue;
                else
                    break;
            }
            if(accountType.equalsIgnoreCase("savings")){
                accounts.add(saccount);
                sa.add(saccount);

            }
            else
                accounts.add(caccount);
            }
        System.out.println("**************************************************"
                + "**********************\n" +
   "*********Invoke getNoofWithdrawals() on SavingsAccount objects**********\n" 
   +"************************************************************************");
        for (SavingsAccount savingaccount : sa){ 
            if(saccount.generateStatement().contains("Savings"))
                System.out.println(savingaccount.getCustomer().
                getFirstName() + " made "+savingaccount.getNoofWithdrawals() 
                        + " withdrawals in this month.");
        }
     
        System.out.println("***************************************************"
                + "********************\n" +
   "****Invoke generateStatement() on all objects in accounts ArrayList****\n" +
    "************************************************************************");
        
        for(Account a1:accounts)
            System.out.println(a1.generateStatement()
                    +"\n****************************************************"
                            + "***************************");
    }
}
