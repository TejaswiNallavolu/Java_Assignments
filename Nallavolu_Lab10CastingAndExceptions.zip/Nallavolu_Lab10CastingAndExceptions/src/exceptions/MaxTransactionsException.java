/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptions;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class MaxTransactionsException extends Exception {

    /**
     * this is a constructor
     * @param msg is the detail message.
     */
    public MaxTransactionsException(String msg) {
        super(msg);
    }

}
