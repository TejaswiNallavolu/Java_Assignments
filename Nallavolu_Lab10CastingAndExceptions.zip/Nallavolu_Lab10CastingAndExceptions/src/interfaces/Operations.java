/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

import accounts.Transaction;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public interface Operations {
    /**
     * OVERDRAFT_LIMIT of the customer
     */
    static double OVERDRAFT_LIMIT = 500;

    /**
     * SAVING_INTEREST of the customer
     */
    static double SAVING_INTEREST = 5.8;
    
    /**
     * method to generate statement
     * @return statement 
     */
    public String generateStatement();
    
    /**
     * method to return transaction 
     * @param transaction
     * @return transaction of the  customer
     * @throws Exception
     */
    public double makeTransaction(Transaction transaction) throws Exception;

}
