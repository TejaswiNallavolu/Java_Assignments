/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enums;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public enum TransactionType {
    /**
     * DEPOSIT is a ENUM constant
     */
    DEPOSIT,

    /**
     * ONLINEPURCHASE is a ENUM constant
     */
    ONLINEPURCHASE,

    /**
     * WITHDRAW is a ENUM constant
     */
    WITHDRAW;
}


