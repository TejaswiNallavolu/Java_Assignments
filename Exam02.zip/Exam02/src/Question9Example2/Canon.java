/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Question9Example2;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class Canon implements Camera {

    @Override
    public void click() {
        System.out.println("A Virtual World of Live Pictures.");
        
    }
    
}
