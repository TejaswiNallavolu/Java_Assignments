/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Question8;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class Chevrolet extends Trucks {

    @Override
    public void speed() {
        System.out.println("The speed of Chevrolet is more higher than any other trucks");
    }
    
}
