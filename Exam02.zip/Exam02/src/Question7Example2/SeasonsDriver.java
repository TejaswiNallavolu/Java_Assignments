/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Question7Example2;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class SeasonsDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println(DifferentSeasons.SPRING.getClimate()+" in Spring.");
        System.out.println(DifferentSeasons.SUMMER.getClimate()+" in Summer.");
        System.out.println(DifferentSeasons.WINTER.getClimate()+" in Winter.");
    }
    
}
