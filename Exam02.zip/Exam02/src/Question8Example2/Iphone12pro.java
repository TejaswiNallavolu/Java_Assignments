/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Question8Example2;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class Iphone12pro extends Iphone {

    public void showConfiguration() {
        System.out.println("8 GB, IOS 14.1");
    }

}
