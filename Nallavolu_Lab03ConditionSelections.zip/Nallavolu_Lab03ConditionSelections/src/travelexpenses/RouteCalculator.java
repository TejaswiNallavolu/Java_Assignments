/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package travelexpenses;

/**
 * it is a RouteCalculator class which is used to calculate the given parameters
 * @author Tejaswi Reddy Nallavolu
 */
public class RouteCalculator {
    private int routeNo;
    private int numpassengers;
    private boolean isMember;
    private boolean isFirstTimeUser;
    private boolean haveCoupon;
    private static final double Coupon=5.00;
    private static final double salesTax=7.50;
    
    /**
     * parameterized constructor which is used to initialize objects
     * @param routeNo
     * @param numpassengers
     * @param isMember
     * @param isFirstTimeUser
     * @param haveCoupon
     */
    public RouteCalculator(int routeNo, int numpassengers, boolean isMember, boolean isFirstTimeUser, boolean haveCoupon){
    this.routeNo = routeNo;
    this.numpassengers = numpassengers;
    this.isMember = isMember;
    this.isFirstTimeUser = isFirstTimeUser;
    this.haveCoupon = haveCoupon;
    
    
    }

    /**
     * to get RouteNo
     *
     * @return
     */
    public int getRouteNo() {
        return routeNo;
    }

    /**
     * to set routeNo
     * @param routeNo
     */
    public void setRouteNo(int routeNo) {
        this.routeNo = routeNo;
    }

    /**
     *to get numpassengers
     * @return
     */
    public int getNumpassengers() {
        return numpassengers;
    }

    /**
     * to set numpassengers
     * @param numpassengers
     */
    public void setNumpassengers(int numpassengers) {
        this.numpassengers = numpassengers;
    }

    /**
     * to get isIsMember true or false
     * @return
     */
    public boolean isIsMember() {
        return isMember;
    }

    /**
     * to set isMember
     * @param isMember
     */
    public void setIsMember(boolean isMember) {
        this.isMember = isMember;
    }

    /**
     * to set isFirstTimeUser
     * @param isFirstTimeUser
     */
    public void setIsFirstTimeUser(boolean isFirstTimeUser) {
        this.isFirstTimeUser = isFirstTimeUser;
    }

    /**
     * to get isFirstTimeUser
     * @return
     */
    public boolean isFirstTimeUser(){
        return isFirstTimeUser;
        
    }
    /**
     * to return tostring
     * @return 
     */
    @Override
    public String toString() {
        return "routeNo: " + routeNo + ", numpassengers: " + numpassengers + ", isMember: " + isMember + ", isFirstTimeUser: " + isFirstTimeUser + ", haveCoupon: " + haveCoupon;
    }
   
    private double calcRoutePrice(){
        if(routeNo==1){
            if(numpassengers==1){
                return 35;
           
            }
            if(numpassengers==2){
                return 60;
            }
            else return numpassengers*26.50;
            
        }
        else if(routeNo==2){
            if(numpassengers==1){
                return 32.89;
           
            }
            if(numpassengers==2){
                return 53.12;
            }
            else return numpassengers*24.20;
            
          }
         
        else{
            if(numpassengers==1){
                return 38;
            
            }
            if(numpassengers==2){
                return 63.78;
            }
            else return numpassengers*28.78;
            
         }
    }
         private double calcMembershipDiscount(){
             if(isMember==true){
                 if(numpassengers==1){
                     return calcRoutePrice()*5;
                 }
                 if(numpassengers==2){
                     return calcRoutePrice()*6.2;
                    
                 }
                 else return calcRoutePrice()*8;
             }
             else return 0.0;  
         }
         private double calFirstTimeUserDiscount(){
              if(isFirstTimeUser==true){
                 if(numpassengers==1){
                  return 10;
                 }
                 if(numpassengers==2){
                     return 7;
                 }
                 else return 4;
              }
              else return 0.0;
              
         }
         private double calcCouponDiscount(){
             if(haveCoupon==true){
                 return calcRoutePrice()-Coupon ;
             }
             else return 0.0;
         }
                 
            private double totalPrice(){
                return calcCouponDiscount()-calFirstTimeUserDiscount()/100.0-calcMembershipDiscount()/100.0;
                
                
            }     
           private double totalPriceWithSalesTax(){
               return totalPrice()*(100+salesTax)/100.0;
               
           }      

    /**
     * used to print the receipt in output
     * @return
     */
    public String printReceipt(){
              return " Receipt \nTravel Charges for " + numpassengers
                + " passengers on route " + routeNo + ": $"
                + this.calcRoutePrice()
                + "\nMembership Discount: $"
                + this.calcMembershipDiscount() / 100.0
                + "\nFirst Time user discount: $"
                + this.calFirstTimeUserDiscount() / 100.0
                + "\nCoupon Discount: $" + this.calcCouponDiscount()
                + "\nCharges After applying Discount: $"
                + Math.round(this.totalPrice() * 100.0) / 100.0
                + "\nTotal Price with Tax: $"
                + Math.round(this.totalPriceWithSalesTax() * 100.0) / 100.0;
           
    }
        
    
}
