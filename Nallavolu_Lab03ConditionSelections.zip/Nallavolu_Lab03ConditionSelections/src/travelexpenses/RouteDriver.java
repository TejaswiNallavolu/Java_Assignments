/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package travelexpenses;

import java.util.Scanner;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class RouteDriver {
/**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    Scanner scan = new Scanner(System.in);
        System.out.println("Enter User Details:");
        System.out.print("Select the routes from 1,2 and 3: ");
        int routeNo=scan.nextInt();
        System.out.print("How many number of passengers: ");
        int numpassengers=scan.nextInt();
        System.out.print("Are you a member: ");
        boolean isMember=scan.nextBoolean();
        System.out.print("Are you a first time user: ");
        boolean isFirstTimeUser=scan.nextBoolean();
        System.out.print("Do you have coupon: ");
         boolean haveCoupon=scan.nextBoolean();
         System.out.println("\n*******************************\n");
         RouteCalculator routeCal= new RouteCalculator(routeNo, numpassengers, isMember, isFirstTimeUser, haveCoupon);
         
         
         
         if(routeNo>3 || routeNo<=0){
             System.out.println("Route number should be 1 or 2 or 3");
         }
         if (numpassengers<=0){
             System.out.println("Passenger number can't be zero.");
         }
         
        if (isMember==true && isFirstTimeUser==true){
            System.out.println("User cannot be a member and first time user at a time.");
            
        }
        if(!(routeNo>3 || routeNo<=0) && !(numpassengers<=0) && !(isMember==true && isFirstTimeUser==true)){
            System.out.println("User Route details: ");
            System.out.println(routeCal);
            System.out.println("\n*******************************\n");
            System.out.println(routeCal.printReceipt());
        }
        else{
            System.out.println("Please try again.");
        }
        
       
        
        
        
        
    }
    
}
    
    
    
    
    
    
    
    
    
    
    