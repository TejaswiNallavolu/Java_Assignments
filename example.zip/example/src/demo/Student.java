/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class Student {
    private int studentID;
    private String studentName;
    private double gpa;
    
    

public Student(int studentID, String studentName, double gpa)
{
    this.studentID=studentID;
    this.studentName=studentName;
    this.gpa=gpa;
}

    public int getStudentID() {
        return studentID;
    }

    public String getStudentName() {
        return studentName;
    }

    public double getGpa() {
        return gpa;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }






}