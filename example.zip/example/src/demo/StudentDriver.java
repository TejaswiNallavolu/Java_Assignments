/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo;

import java.util.*;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class StudentDriver {   

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<Student> myStudents= new ArrayList<Student>();
        //ArrayList<Student> student1= new ArrayList<>();
       Student s1= new Student(1, "krithi", 9.0);
         Student s2= new Student(2, "samvid", 8.0);
       Student s3= new Student(3, "Rithu", 7.0);
       Student s4= new Student(4, "Anie", 9.9);
       Student s5= new Student(5, "Rinky", 7.8);
       myStudents.add(s1);
       myStudents.add(s2);
       myStudents.add(s3);
       myStudents.add(s4);
       myStudents.add(s5);
       double highest=0.0, lowest=myStudents.get(0).getGpa();
       
       for(Student a: myStudents){
           if(a.getGpa()>highest){
               highest=a.getGpa();
           }
       }
       System.out.println("The highest num is: "+highest);
       for(Student b: myStudents){
           if(b.getGpa()<lowest){
               lowest=b.getGpa();
           }
           
       }
       
        System.out.println("the lowest num is: "+lowest);
    
    double d=0;
   for(Student c: myStudents){
    d=d+c.getGpa();
   }    
   System.out.println("The average is:"+d/myStudents.size());
   String p="";
   for(Student e: myStudents){
       if(e.getStudentName().equalsIgnoreCase("s"))
           p=e.getStudentName();
   }
   System.out.println("The students names which start with s are: "+p);
   
}
}
