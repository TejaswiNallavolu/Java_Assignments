/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package starbucks;

import java.util.Scanner;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class StarbucksDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODvvO code application logic here
        Scanner scan = new Scanner(System.in);

        String item;
        int orderNumber = 1;//to increment order number
        String orders="Y";
        System.out.println("***** Welcome to Starbucks *****");
        while (orders.equals("Y")) {
            System.out.print("Please enter the full name (Firstname Lastname): ");
            String customerName = scan.nextLine();
            while (customerName.equals("")) {
                System.out.print("Please enter the full name (Firstname Lastname): ");
                customerName = scan.nextLine();
            }
            System.out.print("Please enter the Address: ");
            String customerAddress = scan.nextLine();
            while (customerAddress.equals("")) {
                System.out.print("Please enter the Address: ");
                customerAddress = scan.nextLine();
            }
            System.out.print("Please enter Contact Number: ");
            String customerContact = scan.next();
            while (!(customerContact.length()>0) || customerContact.length() > 10) {
                System.out.print("Please enter Contact Number: ");
                customerContact = scan.next();
            }
            System.out.print("Please enter Customer Type(Regular/New): ");
            String customerType = scan.next();
            while (!customerType.equals("Regular") && !customerType.equals("New")) {
                System.out.print("Please enter Customer Type(Regular/New): ");
                customerType = scan.next();
            }
            Starbucks sb = new Starbucks(customerName, customerAddress, customerContact, customerType);
            System.out.println("!*!*!*!*! Welcome Board " + customerName + " !*!*!*!*!");
           do {
                System.out.println("Select items from following list\n"
                        + "1.Ham & Swiss Panini\n"
                        + "2.Cheese & Fruit Bistro Box\n"
                        + "3.Turkey Pesto Panini\n"
                        + "4.Salted Caramel or Birthday Cake Pop\n"
                        + "5.Roasted Tomato & Mozzarella Panini");
                int itemNumber = scan.nextInt();
                while (itemNumber < 1 || itemNumber > 5) {
                    System.out.println("Please choose the number 1 to 5");
                    itemNumber = scan.nextInt();
                }
                System.out.print("Enter the quantity: ");
                int itemQuantity = scan.nextInt();
                sb.updateReceipt(itemQuantity, itemNumber);
                System.out.print("Do you want to add one more item(Y/N))? ");
                item = scan.next();
            }  while (item.equals("Y"));
            System.out.println("Bill amount is " + sb.getFinalBillAmount());
            System.out.print("Enter the cash paid: $");
            double givenAmount = scan.nextDouble();
            scan.nextLine();
            System.out.println("***************************************");
            sb.setOrder("Order - " + (orderNumber++));
            if (givenAmount >= sb.getFinalBillAmount()) {
                System.out.println(sb.printReciept(givenAmount));
            }
            System.out.println("***************************************");
            System.out.print("Do you want add one more order(Y/N))? ");
            orders = scan.nextLine();
        } 
        System.out.println("Thank you!");
    }
}
    
