/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package starbucks;

/**
 *
 * @author Tejaswi Reddy Nallavolu
 */
public class Starbucks {

    private String customerName;
    private String address;
    private String contactNumber;
    private String customerType;
    private String billReciept = "";
    private double billAmount = 0;
    private String order = "";

    /**
     * this method is a constructor
     *
     * @param customerName
     * @param address
     * @param contactNumber
     * @param customerType
     */
    public Starbucks(String customerName, String address,
            String contactNumber, String customerType) {
        this.customerName = customerName;
        this.address = address;
        this.contactNumber = contactNumber;
        this.customerType = customerType;
    }

    /**
     * to get customerName
     *
     * @return customerName
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * to set customerName
     *
     * @param customerName
     */
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    /**
     * to get customer address
     *
     * @return address
     */
    public String getAddress() {
        return address;
    }

    /**
     * to set address
     *
     * @param address
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * to get contactNumber
     *
     * @return contactNumber
     */
    public String getContactNumber() {
        return contactNumber;
    }

    /**
     * to set contactNumber
     *
     * @param contactNumber
     */
    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    /**
     * to get customerType
     *
     * @return customerType
     */
    public String getCustomerType() {
        return customerType;
    }

    /**
     * to set customerType
     *
     * @param customerType
     */
    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    /**
     * to get billReciept
     *
     * @return billReciept
     */
    public String getBillReciept() {
        return billReciept;
    }

    /**
     * to set billReciept
     *
     * @param billReciept
     */
    public void setBillReciept(String billReciept) {
        this.billReciept = billReciept;
    }

    /**
     * to get billAmount
     *
     * @return billAmount
     */
    public double getBillAmount() {
        return billAmount;
    }

    /**
     * to set billAmount
     *
     * @param billAmount
     */
    public void setBillAmount(double billAmount) {
        this.billAmount = billAmount;
    }

    /**
     * to get order
     *
     * @return order
     */
    public String getOrder() {
        return order;
    }

    /**
     * to set order
     *
     * @param order
     */
    public void setOrder(String order) {
        this.order = order;
    }

    /**
     * to get customerInitials
     *
     * @return customerInitials
     */
    public String getNameInitials() {
        String customerInitials = "";
        String customerNameCap = this.customerName.toUpperCase();
        for (int i = 0; i < this.customerName.length(); i++) {
            if (i == 0) {
                customerInitials = customerInitials + customerNameCap.charAt(0) + ".";
            } else if (customerNameCap.charAt(i - 1) == ' ') {
                customerInitials = customerInitials + customerNameCap.charAt(i) + ".";
            }
        }
        return customerInitials;

    }

    private String getItemName(int itemNumber) {

        String itemName = "";
        switch (itemNumber) {
            case 1:
                itemName = "Ham & Swiss Panini";
                break;
            case 2:
                itemName = "Cheese & Fruit Bistro Box";
                break;
            case 3:
                itemName = "Turkey Pesto Panini";
                break;
            case 4:
                itemName = "Salted Caramel or Birthday Cake Pop";
                break;
            case 5:
                itemName = "Roasted Tomato & Mozzarella Panini";
                break;
        }
        return itemName;
    }

    private double getItemCost(String itemName) {
        double price = 0.0;
        switch (itemName) {
            case "Ham & Swiss Panini":
                price = 5.25;
                break;
            case "Cheese & Fruit Bistro Box":
                price = 4.95;
                break;
            case "Turkey Pesto Panini":
                price = 5.96;
                break;
            case "Salted Caramel or Birthday Cake Pop":
                price = 3.50;
                break;
            case "Roasted Tomato & Mozzarella Panini":
                price = 3.46;
                break;
        }
        return price;

    }

    /**
     *
     * @param quantity
     * @param itemNumber
     */
    public void updateReceipt(int quantity, int itemNumber) {
        String itemName = getItemName(itemNumber);
        double itemCost = getItemCost(itemName);
        int spaces= 39-itemName.length();
        billAmount = billAmount + (itemCost * quantity);
        this.billReciept += String.format("%" + spaces,  "s", "")+itemName + "(" + itemCost + ")" + "  *" + quantity + " = "
                + Math.round((itemCost * quantity) * 100) / 100.0 +"\n";
        System.out.println();

    }

    /**
     * to get Discount
     *
     * @return
     */
    private double getDiscount() {
        if (customerType.equals("Regular") && this.billAmount > 10) {
            return Math.round(billAmount * (10 / 100.0) * 100) / 100.0;
        } else {
            return 0.0;
        }

    }

    /**
     * to get SalesTax
     *
     * @return
     */
    private double getSalesTax() {
        return Math.round(billAmount * (8 / 100.0) * 100) / 100.0;
    }

    /**
     * to get finalBill
     *
     * @return
     */
    public double getFinalBillAmount() {
        double finalBill = billAmount + this.getSalesTax() - this.getDiscount();
        return Math.round(finalBill * 100) / 100.0;
    }

    /**
     * to get FinalBillReciept
     *
     * @return string
     */
    private String getFinalBillReciept() {
        String itemName="";
        int spaces=38-itemName.length();
        String.format("%" + spaces,  "s", "");
        return "The Following is the bill for purchased products\n"
                + this.billReciept
                + String.format("%" + spaces,  "s", "")+"Sales Tax = "
                + this.getSalesTax()+String.format("%" + spaces,  "s", "")
                +"discount = "+ this.getDiscount()
                + "\n-------------------------------------------------------\n"
                + "                                Total Bill = "
                + this.getFinalBillAmount()
                + "\n-------------------------------------------------------\n";
    }

    /**
     * to get ContactDetails
     *
     * @return
     */
    private String getContactDetails() {
        return "Address: " + this.address + "\nContact: " + this.contactNumber;
    }

    /**
     * to get OrderWithName
     *
     * @return
     */
    private String getOrderWithName() {
        return order + " by " + this.getNameInitials();
    }

    @Override
    public String toString() {
        return getOrderWithName() + "\n" + getContactDetails()
                + "\n" + getFinalBillReciept();
    }

    /**
     * to get amountGiven
     *
     * @param amountGiven
     * @return Change received is as follow
     */
  

    private String getBalance(double amount) {

        String sheet = "";
        sheet = "Change received is as follow";
        double amt = amount - this.getFinalBillAmount();
        while (amt >= 50) {
            sheet += "\n50.00    *" + (int) Math.floor(amt / 50) + " = " + 50 * Math.floor(amt / 50.0);
            amt = amt % 50;
            break;
        }
        while (amt >= 10) {
            sheet += "\n10.00   *" + (int) Math.floor(amt / 10) + " = " + 10 * Math.floor(amt / 10.0);
            amt = amt % 10;
            break;
        }
        while (amt >= 5) {
            sheet += "\n5.00    *" + (int) Math.floor(amt / 5) + " = " + 5 * Math.floor(amt / 5.0);
            amt = amt % 5;
            break;
        }
        while (amt >= 1) {
            sheet += "\n1.00   *" + (int) Math.floor(amt / 1) + " = " + 1 * Math.floor(amt / 1.0);
            amt = amt % 1;
            break;
        }
        while (amt >= 0.25) {
            sheet += "\n0.25   *" + (int) Math.floor(amt / 0.25) + " = " + 0.25 * Math.floor(amt / 0.25);
            amt = amt % 0.25;
            break;
        }
        while (amt >= 0.10) {
            sheet += "\n0.10 *" + (int) Math.floor(amt / 0.10) + " = " + 0.10 * Math.floor(amt / 0.10);
            amt = amt % 0.10;
            break;
        }
        while (amt >= 0.05) {
            sheet += "\n0.05  *" + (int) Math.floor(amt / 0.05) + " = " + 0.05 * Math.floor(amt / 0.05);
            amt = amt % 0.05;
            break;
        }
        while (amt >= 0.01) {
            sheet += "\n0.01  *" + (int) Math.floor(amt / 0.01) + " = " + 0.01 * Math.floor(amt / 0.01);
            amt = amt % 0.01;
            break;
        }

        return sheet + "\n-------------------------\n    "
                + "Total Bal ="
                + Math.round((amount - this.getFinalBillAmount()) * 100) / 100.0 + "\n------------------------------------\n";

    }

    /**
     * to return printReciept
     *
     * @param billAmount
     * @return
     */
    public String printReciept(double billAmount) {
        return toString()
                + getBalance(billAmount);
    }

}
